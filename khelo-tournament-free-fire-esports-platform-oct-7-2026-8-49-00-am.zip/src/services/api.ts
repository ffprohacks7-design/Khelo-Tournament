import { 
  Tournament, 
  User, 
  Banner, 
  NotificationItem, 
  Transaction, 
  MatchResult, 
  AppSettings, 
  SupportTicket, 
  Participant 
} from '../types';

const BASE = '/api';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    let errMsg = 'Request failed';
    try {
      const data = await res.json();
      errMsg = data.error || data.message || errMsg;
    } catch {
      // ignore
    }
    throw new Error(errMsg);
  }

  return res.json();
}

export const api = {
  // Settings
  getSettings: () => request<AppSettings>('/settings'),
  updateSettings: (data: Partial<AppSettings>) => request<AppSettings>('/settings', {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  // Banners
  getBanners: () => request<Banner[]>('/banners'),
  createBanner: (data: Partial<Banner>) => request<Banner>('/banners', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  updateBanner: (id: string, data: Partial<Banner>) => request<Banner>(`/banners/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  deleteBanner: (id: string) => request<{ success: boolean }>(`/banners/${id}`, {
    method: 'DELETE',
  }),

  // Users & Auth
  login: (login: string, password?: string, role?: string) => request<{ user: User; token: string }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ login, password, role }),
  }),
  register: (data: Partial<User>) => request<{ user: User; token: string }>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getUsers: () => request<User[]>('/users'),
  updateUser: (id: string, data: Partial<User>) => request<User>(`/users/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  // Tournaments
  getTournaments: () => request<Tournament[]>('/tournaments'),
  getTournament: (id: string) => request<Tournament>(`/tournaments/${id}`),
  createTournament: (data: Partial<Tournament>) => request<Tournament>('/tournaments', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  updateTournament: (id: string, data: Partial<Tournament>) => request<Tournament>(`/tournaments/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  deleteTournament: (id: string) => request<{ success: boolean }>(`/tournaments/${id}`, {
    method: 'DELETE',
  }),
  joinTournament: (id: string, payload: { userId: string; playerName?: string; ffUid?: string; teamName?: string }) => 
    request<{ success: boolean; participant: Participant; tournament: Tournament; user: User }>(`/tournaments/${id}/join`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateRoom: (id: string, payload: { roomId?: string; roomPassword?: string; isRoomPublished?: boolean }) =>
    request<Tournament>(`/tournaments/${id}/room`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  // Participants
  getParticipants: (tournamentId: string) => request<Participant[]>(`/tournaments/${tournamentId}/participants`),
  removeParticipant: (tournamentId: string, userId: string) => 
    request<{ success: boolean }>(`/tournaments/${tournamentId}/participants/${userId}`, {
      method: 'DELETE',
    }),

  // Results
  getResults: () => request<MatchResult[]>('/results'),
  publishResults: (tournamentId: string, results: Partial<MatchResult>[]) => 
    request<{ success: boolean; tournament: Tournament; results: MatchResult[] }>(`/tournaments/${tournamentId}/results`, {
      method: 'POST',
      body: JSON.stringify({ results }),
    }),

  // Wallet & Transactions
  getTransactions: (userId?: string) => 
    request<Transaction[]>(`/wallet/transactions${userId ? `?userId=${userId}` : ''}`),
  deposit: (payload: { userId: string; amount: number; paymentMethod: string; accountNumber: string; transactionRef?: string }) =>
    request<Transaction>('/wallet/deposit', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  withdraw: (payload: { userId: string; amount: number; paymentMethod: string; accountNumber: string }) =>
    request<{ transaction: Transaction; newBalance: number }>('/wallet/withdraw', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  reviewTransaction: (id: string, status: 'Approved' | 'Rejected') =>
    request<Transaction>(`/wallet/transactions/${id}/review`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),
  adjustWallet: (payload: { userId: string; amount: number; description: string; type?: string }) =>
    request<{ transaction: Transaction; user: User }>('/wallet/adjust', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Notifications
  getNotifications: () => request<NotificationItem[]>('/notifications'),
  sendNotification: (payload: { title: string; message: string; target?: 'all' | 'tournament' | 'user'; targetId?: string; type?: string }) =>
    request<NotificationItem>('/notifications', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  markNotificationRead: (id: string) => request<{ success: boolean }>(`/notifications/${id}/read`, {
    method: 'PUT',
  }),

  // Support
  getSupportTickets: () => request<SupportTicket[]>('/support/tickets'),
  createSupportTicket: (payload: { userId?: string; userName?: string; userPhone?: string; subject: string; message: string }) =>
    request<SupportTicket>('/support/tickets', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateSupportTicket: (id: string, status: 'Open' | 'Resolved') =>
    request<SupportTicket>(`/support/tickets/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),
};
