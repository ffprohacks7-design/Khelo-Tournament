import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, ShieldCheck, User, Mail, Phone, Lock, Hash, Sparkles } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, login, register, setViewMode } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Login form
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');

  // Register form
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [ffUid, setFfUid] = useState('');
  const [inGameName, setInGameName] = useState('');
  const [regPassword, setRegPassword] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const ok = await login(loginId, password);
    setIsSubmitting(false);
    if (ok) setIsAuthModalOpen(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const ok = await register({
      name,
      username,
      email,
      phone,
      ffUid,
      inGameName: inGameName || username,
    });
    setIsSubmitting(false);
    if (ok) setIsAuthModalOpen(false);
  };

  const handleQuickDemo = async (type: 'rakib' | 'shadow' | 'admin') => {
    if (type === 'rakib') {
      await login('rakib@khelo.gg', 'pass');
    } else if (type === 'shadow') {
      await login('tanvir@khelo.gg', 'pass');
    } else if (type === 'admin') {
      await login('admin@khelo.gg', 'admin123', 'admin');
      setViewMode('admin');
    }
    setIsAuthModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-linear-to-r from-purple-800 to-indigo-900 p-4 text-white flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-black text-base font-gaming tracking-wide uppercase">
              {mode === 'login' ? 'SIGN IN TO KHELO' : 'CREATE PLAYER ACCOUNT'}
            </h3>
            <p className="text-[11px] text-purple-200">
              {mode === 'login' ? 'Access your wallet, matches and tournaments' : 'Get free ৳50 signup bonus!'}
            </p>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Quick Demo Logins Bar */}
          <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200">
            <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              1-Click Instant Demo Login:
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickDemo('rakib')}
                className="py-1.5 px-2 bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold rounded-lg text-[11px] font-gaming truncate"
              >
                ⚡ Rakib (Player)
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('shadow')}
                className="py-1.5 px-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg text-[11px] font-gaming truncate"
              >
                亗 Shadow (Player)
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('admin')}
                className="py-1.5 px-2 bg-indigo-800 hover:bg-indigo-900 text-white font-bold rounded-lg text-[11px] font-gaming truncate"
              >
                🛡️ Admin
              </button>
            </div>
          </div>

          {/* Mode Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold text-slate-600">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${mode === 'login' ? 'bg-white text-purple-800 shadow-2xs' : 'hover:text-slate-900'}`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${mode === 'register' ? 'bg-white text-purple-800 shadow-2xs' : 'hover:text-slate-900'}`}
            >
              Register New
            </button>
          </div>

          {/* LOGIN FORM */}
          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Email, Username, or Phone:
                </label>
                <input
                  type="text"
                  required
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  placeholder="e.g. rakib@khelo.gg or RakibGaming"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Password:</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95"
              >
                {isSubmitting ? 'Signing In...' : 'Sign In'}
              </button>
            </form>
          ) : (
            /* REGISTER FORM */
            <form onSubmit={handleRegister} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tanvir Rahman"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. TanvirGamer"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Free Fire IGN</label>
                  <input
                    type="text"
                    value={inGameName}
                    onChange={(e) => setInGameName(e.target.value)}
                    placeholder="e.g. 亗TANVIR亗"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-gaming"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@email.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Free Fire UID (Number)</label>
                <input
                  type="text"
                  value={ffUid}
                  onChange={(e) => setFfUid(e.target.value)}
                  placeholder="e.g. 918274619"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95"
              >
                {isSubmitting ? 'Creating...' : 'Register & Claim ৳50 Bonus'}
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
