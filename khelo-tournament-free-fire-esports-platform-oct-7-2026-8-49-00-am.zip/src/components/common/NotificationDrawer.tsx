import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Bell, Key, Trophy, Swords, Megaphone, Check } from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const { isNotifDrawerOpen, setIsNotifDrawerOpen, notifications, markNotifAsRead, setSelectedTournament, tournaments, setIsDetailOpen } = useApp();

  if (!isNotifDrawerOpen) return null;

  const handleNotificationClick = (notif: any) => {
    markNotifAsRead(notif.id);
    if (notif.targetId && notif.target === 'tournament') {
      const trn = tournaments.find((t) => t.id === notif.targetId);
      if (trn) {
        setSelectedTournament(trn);
        setIsNotifDrawerOpen(false);
        setIsDetailOpen(true);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs">
      <div className="w-full max-w-sm bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-purple-600" />
            <h3 className="font-black text-base font-gaming tracking-wide uppercase text-slate-900">
              NOTIFICATIONS
            </h3>
          </div>
          <button
            onClick={() => setIsNotifDrawerOpen(false)}
            className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              No notifications yet.
            </div>
          ) : (
            notifications.map((notif) => {
              let icon = <Megaphone className="w-4 h-4 text-purple-600" />;
              let bg = 'bg-purple-50';

              if (notif.type === 'room') {
                icon = <Key className="w-4 h-4 text-emerald-600" />;
                bg = 'bg-emerald-50';
              } else if (notif.type === 'wallet' || notif.type === 'result') {
                icon = <Trophy className="w-4 h-4 text-amber-600" />;
                bg = 'bg-amber-50';
              } else if (notif.type === 'tournament') {
                icon = <Swords className="w-4 h-4 text-blue-600" />;
                bg = 'bg-blue-50';
              }

              return (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`cursor-pointer p-3 rounded-2xl border transition-all ${
                    notif.isRead
                      ? 'bg-white border-slate-200/80 opacity-75'
                      : 'bg-purple-50/40 border-purple-200/90 shadow-2xs font-semibold'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className={`p-2 rounded-xl shrink-0 ${bg}`}>
                      {icon}
                    </div>
                    <div className="flex-1 space-y-0.5">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-slate-900 leading-tight">
                          {notif.title}
                        </h4>
                        {!notif.isRead && (
                          <span className="w-2 h-2 rounded-full bg-purple-600 shrink-0"></span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-normal">
                        {notif.message}
                      </p>
                      <span className="text-[10px] text-slate-400 font-medium block pt-1">
                        {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 bg-slate-50 text-center">
          <button
            onClick={() => {
              notifications.forEach((n) => markNotifAsRead(n.id));
            }}
            className="text-xs font-bold text-purple-700 hover:underline"
          >
            Mark all as read
          </button>
        </div>

      </div>
    </div>
  );
};
