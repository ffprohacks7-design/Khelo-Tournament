import React from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, ShieldCheck, Wallet, Globe, User as UserIcon, Plus } from 'lucide-react';

export const UserNavbar: React.FC = () => {
  const { 
    currentUser, 
    unreadCount, 
    setIsNotifDrawerOpen, 
    setIsWalletModalOpen, 
    setIsAuthModalOpen,
    language, 
    setLanguage, 
    setViewMode,
    settings,
    setActiveTab,
    devicePreviewMode,
    setDevicePreviewMode
  } = useApp();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs px-4 py-2.5">
      {/* Top micro bar for quick device frame toggle & Admin Switch */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs">
        <div className="flex items-center gap-2 text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-semibold text-slate-700 tracking-tight">{settings?.appName || 'KHelo Tournament'}</span>
          <span className="text-[10px] bg-purple-100 text-purple-700 font-bold px-1.5 py-0.5 rounded-sm">ESPORTS</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Toggle between mobile frame and wide view */}
          <button
            onClick={() => setDevicePreviewMode(devicePreviewMode === 'mobile' ? 'fullscreen' : 'mobile')}
            className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium transition-colors text-[11px]"
            title="Toggle Device Frame"
          >
            {devicePreviewMode === 'mobile' ? '📱 Mobile Frame' : '💻 Wide View'}
          </button>

          {/* Switch to Admin Mode Button */}
          <button
            onClick={() => setViewMode('admin')}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-linear-to-r from-purple-700 to-indigo-800 text-white font-bold text-[11px] shadow-xs hover:opacity-95 transition-opacity"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-yellow-300" />
            <span>Admin Panel</span>
          </button>
        </div>
      </div>

      {/* Main Navbar Row */}
      <div className="flex items-center justify-between gap-2">
        {/* Left: User Avatar & Quick Info */}
        <div className="flex items-center gap-2.5">
          {currentUser ? (
            <button 
              onClick={() => setActiveTab('profile')} 
              className="flex items-center gap-2 text-left group"
            >
              <div className="relative">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-10 h-10 rounded-full border-2 border-purple-500/80 bg-purple-50 object-cover shadow-xs group-hover:scale-105 transition-transform"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
              </div>
              <div className="leading-tight">
                <div className="text-sm font-bold text-slate-800 flex items-center gap-1 font-gaming tracking-wide">
                  {currentUser.inGameName || currentUser.username}
                </div>
                <div className="text-[11px] text-slate-500 font-medium">
                  ID: <span className="text-purple-600 font-semibold">{currentUser.id}</span>
                </div>
              </div>
            </button>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 font-bold text-xs hover:bg-purple-100 transition-colors"
            >
              <UserIcon className="w-4 h-4" />
              <span>Login / Register</span>
            </button>
          )}
        </div>

        {/* Right: Wallet Balance, Language & Notification Bell */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Wallet Balance Chip */}
          {currentUser && (
            <button
              onClick={() => setIsWalletModalOpen(true)}
              className="flex items-center gap-1.5 bg-linear-to-r from-amber-50 to-orange-50 border border-amber-200/80 text-amber-900 px-2.5 py-1.5 rounded-full hover:shadow-xs transition-all active:scale-95"
            >
              <div className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                ৳
              </div>
              <span className="font-extrabold text-sm text-slate-900 font-gaming">
                {currentUser.walletBalance}
              </span>
              <div className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </button>
          )}

          {/* Language Switcher */}
          <button
            onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
            title="Toggle Bengali / English"
          >
            <Globe className="w-3.5 h-3.5 text-purple-600" />
            <span>{language === 'bn' ? 'বাং' : 'EN'}</span>
          </button>

          {/* Notification Bell */}
          <button
            onClick={() => setIsNotifDrawerOpen(true)}
            className="relative p-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
