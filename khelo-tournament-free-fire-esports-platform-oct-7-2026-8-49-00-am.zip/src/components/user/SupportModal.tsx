import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Send, Phone, MessageSquare, HelpCircle, ChevronDown, CheckCircle2, ShieldAlert } from 'lucide-react';
import { api } from '../../services/api';

const FAQS = [
  {
    q: 'When will the Room ID and Password be released?',
    a: 'The administrator publishes the custom room ID and password 15 minutes before the match start time. It will immediately show up in the tournament details and in your "My Matches" tab with copy buttons.'
  },
  {
    q: 'How do I claim my cash prize after winning?',
    a: 'Once the admin enters match results and standings, your prize money is automatically credited to your wallet balance. You can withdraw it to your bKash or Nagad account at any time.'
  },
  {
    q: 'Can PC Emulator players join the tournaments?',
    a: 'Unless explicitly stated in the match title or rules as "PC Allowed", all tournaments are strictly for mobile devices. Using emulators without permission will lead to disqualification.'
  },
  {
    q: 'What happens if I get disconnected during a match?',
    a: 'Please rejoin the Free Fire match directly from the game client before the lobby countdown finishes. Tournaments start automatically according to room schedule.'
  }
];

export const SupportModal: React.FC = () => {
  const { isSupportModalOpen, setIsSupportModalOpen, settings, currentUser, showToast } = useApp();
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [isSending, setIsSending] = useState(false);

  if (!isSupportModalOpen) return null;

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      showToast('Please type your message', 'error');
      return;
    }

    try {
      setIsSending(true);
      await api.createSupportTicket({
        userId: currentUser?.id,
        userName: currentUser?.name || 'Player',
        userPhone: phone,
        subject: subject.trim() || 'General Inquiry',
        message: message.trim(),
      });
      showToast('Support ticket sent! Admin will review shortly.', 'success');
      setMessage('');
      setSubject('');
      setIsSupportModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Failed to send ticket', 'error');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-linear-to-r from-blue-700 via-indigo-700 to-purple-800 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-black">
              <MessageSquare className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <h3 className="font-black text-base font-gaming tracking-wide">
                HELP & SUPPORT CENTER
              </h3>
              <p className="text-[11px] text-blue-100">
                24/7 Community Support & Tournament Inquiries
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSupportModalOpen(false)}
            className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Quick Channels - Telegram Banner link */}
          <div className="grid grid-cols-2 gap-2.5">
            <a
              href={settings?.telegramLink || 'https://t.me/khelobangladesh_live'}
              target="_blank"
              rel="noreferrer"
              className="p-3 rounded-2xl bg-linear-to-br from-blue-500 to-blue-700 text-white flex flex-col justify-between hover:opacity-95 shadow-md shadow-blue-500/20 transition-transform active:scale-95"
            >
              <div className="flex items-center justify-between">
                <Send className="w-5 h-5 -translate-x-0.5" />
                <span className="text-[10px] bg-white/20 font-bold px-2 py-0.5 rounded-full uppercase">
                  ACTIVE
                </span>
              </div>
              <div className="mt-3">
                <h4 className="font-extrabold text-sm font-gaming">Telegram Channel</h4>
                <p className="text-[10px] text-blue-100 font-mono mt-0.5">
                  {settings?.telegramChannelName || '@khelobangladesh_live'}
                </p>
              </div>
            </a>

            <div className="p-3 rounded-2xl bg-linear-to-br from-emerald-600 to-teal-700 text-white flex flex-col justify-between shadow-md shadow-emerald-500/20">
              <div className="flex items-center justify-between">
                <Phone className="w-5 h-5" />
                <span className="text-[10px] bg-white/20 font-bold px-2 py-0.5 rounded-full uppercase">
                  HELPLINE
                </span>
              </div>
              <div className="mt-3">
                <h4 className="font-extrabold text-sm font-gaming">WhatsApp Support</h4>
                <p className="text-[10px] text-emerald-100 font-mono mt-0.5">
                  {settings?.whatsappSupport || '+8801700000000'}
                </p>
              </div>
            </div>
          </div>

          {/* FAQs */}
          <div className="space-y-2">
            <h4 className="font-extrabold text-slate-800 uppercase font-gaming tracking-wide flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-purple-600" />
              Frequently Asked Questions (FAQ)
            </h4>

            <div className="space-y-1.5">
              {FAQS.map((faq, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 overflow-hidden bg-slate-50 transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                    className="w-full p-2.5 text-left font-bold text-slate-800 flex items-center justify-between gap-2"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${activeFaq === idx ? 'rotate-180 text-purple-600' : ''}`} />
                  </button>
                  {activeFaq === idx && (
                    <div className="p-2.5 pt-0 text-slate-600 text-[11px] leading-relaxed border-t border-slate-100 bg-white">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Contact Admin / Report Issue Form */}
          <form onSubmit={handleSubmitTicket} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <h4 className="font-bold text-slate-800 uppercase font-gaming">
              Report a Problem or Contact Admin
            </h4>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Subject:</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Room password not working, Payment issue"
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 focus:border-purple-600 outline-hidden bg-white text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Contact Phone:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. 01712345678"
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 focus:border-purple-600 outline-hidden bg-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Detailed Message:</label>
              <textarea
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your question or issue in detail..."
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 focus:border-purple-600 outline-hidden bg-white text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={isSending}
              className="w-full py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold uppercase tracking-wider text-xs shadow-md transition-all active:scale-95"
            >
              {isSending ? 'Sending...' : 'Send Message to Admin'}
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
