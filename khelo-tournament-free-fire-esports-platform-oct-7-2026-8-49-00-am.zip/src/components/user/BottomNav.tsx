import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShoppingCart, Gamepad2, Swords, Trophy, User, Send, Headphones } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, setIsSupportModalOpen, setIsShopModalOpen, t } = useApp();

  const NAV_ITEMS = [
    {
      id: 'shop',
      label: t.shop,
      icon: <ShoppingCart className="w-5 h-5" />,
      action: () => setIsShopModalOpen(true),
    },
    {
      id: 'play',
      label: t.play,
      icon: <Gamepad2 className="w-5 h-5" />,
      action: () => setActiveTab('play'),
    },
    {
      id: 'matches',
      label: t.myMatches,
      icon: <Swords className="w-5 h-5" />,
      action: () => setActiveTab('matches'),
    },
    {
      id: 'results',
      label: t.results,
      icon: <Trophy className="w-5 h-5" />,
      action: () => setActiveTab('results'),
    },
    {
      id: 'profile',
      label: t.profile,
      icon: <User className="w-5 h-5" />,
      action: () => setActiveTab('profile'),
    },
  ];

  return (
    <>
      {/* Floating Telegram / Support Assistant Mascot matching screenshot */}
      <div className="fixed bottom-20 right-4 z-30">
        <button
          onClick={() => setIsSupportModalOpen(true)}
          className="relative group w-13 h-13 rounded-full bg-linear-to-tr from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-xl shadow-blue-500/30 border-2 border-white hover:scale-105 active:scale-95 transition-transform"
          title="Telegram Community & Support"
        >
          {/* Pulsing glow ring */}
          <span className="absolute -inset-1 rounded-full bg-cyan-400 opacity-40 group-hover:opacity-75 blur-xs animate-pulse"></span>
          
          {/* Mascot icon */}
          <div className="relative z-10 flex flex-col items-center justify-center">
            <Headphones className="w-6 h-6 text-yellow-300 drop-shadow-xs" />
          </div>

          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full"></span>
        </button>
      </div>

      {/* Bottom Navigation Bar matching reference design */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] py-1.5 px-3">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={item.action}
                className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 ${
                  isActive
                    ? 'text-purple-700 font-bold scale-105'
                    : 'text-slate-500 hover:text-slate-800 font-medium'
                }`}
              >
                {/* Active Indicator Glow/Pill */}
                {isActive && (
                  <span className="absolute inset-0 bg-purple-100/80 rounded-2xl -z-10 animate-in zoom-in-75 duration-200" />
                )}

                <div className={`p-1 rounded-xl transition-transform ${isActive ? 'text-purple-700' : 'text-slate-500'}`}>
                  {item.icon}
                </div>

                <span className={`text-[11px] leading-tight font-gaming tracking-tight mt-0.5 ${isActive ? 'font-black' : ''}`}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
