import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, ShieldCheck, Wallet, AlertCircle, ArrowRight, Check } from 'lucide-react';

export const JoinTournamentModal: React.FC = () => {
  const { 
    selectedTournament, 
    isJoinModalOpen, 
    setIsJoinModalOpen, 
    currentUser, 
    joinTournament, 
    setIsWalletModalOpen,
    setIsAuthModalOpen,
    showToast,
    t 
  } = useApp();

  const [ffUid, setFfUid] = useState('');
  const [playerName, setPlayerName] = useState('');
  const [teamName, setTeamName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setFfUid(currentUser.ffUid || '');
      setPlayerName(currentUser.inGameName || currentUser.username || '');
    }
  }, [currentUser, isJoinModalOpen]);

  if (!isJoinModalOpen || !selectedTournament) return null;

  const entryFee = selectedTournament.entryFee;
  const currentBalance = currentUser?.walletBalance || 0;
  const isInsufficient = currentBalance < entryFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
      setIsJoinModalOpen(false);
      setIsAuthModalOpen(true);
      return;
    }

    if (!ffUid.trim()) {
      showToast('Please enter your Free Fire UID', 'error');
      return;
    }

    if (!playerName.trim()) {
      showToast('Please enter your In-Game Name (IGN)', 'error');
      return;
    }

    if (isInsufficient) {
      showToast(t.insufficientBalance, 'error');
      setIsJoinModalOpen(false);
      setIsWalletModalOpen(true);
      return;
    }

    setIsSubmitting(true);
    const success = await joinTournament(selectedTournament.id, {
      ffUid: ffUid.trim(),
      playerName: playerName.trim(),
      teamName: teamName.trim() || undefined,
    });
    setIsSubmitting(false);

    if (success) {
      setIsJoinModalOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-linear-to-r from-purple-800 to-indigo-900 p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-yellow-300" />
            <h3 className="font-black text-base font-gaming tracking-wide">
              CONFIRM REGISTRATION
            </h3>
          </div>
          <button
            onClick={() => setIsJoinModalOpen(false)}
            className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4">
          {/* Tournament Overview */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div>
              <h4 className="font-extrabold text-sm text-slate-800 font-gaming">
                {selectedTournament.title}
              </h4>
              <p className="text-xs text-slate-500">
                {selectedTournament.gameMode} • {selectedTournament.matchType} • {selectedTournament.map}
              </p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">Entry Fee</span>
              <span className="font-black text-base text-purple-700 font-gaming">
                {entryFee === 0 ? 'FREE' : `৳${entryFee}`}
              </span>
            </div>
          </div>

          {/* Inputs */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.freeFireUid} <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={ffUid}
                onChange={(e) => setFfUid(e.target.value)}
                placeholder="e.g. 839201948"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 focus:ring-2 focus:ring-purple-200 outline-hidden text-sm font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-0.5">Find this in your Free Fire profile banner.</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.inGameName} <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="e.g. ⚡RAKIB_FF⚡"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 focus:ring-2 focus:ring-purple-200 outline-hidden text-sm font-gaming"
              />
            </div>

            {selectedTournament.matchType !== 'Solo' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Team Name (Optional)
                </label>
                <input
                  type="text"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="e.g. Squad Elite"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 focus:ring-2 focus:ring-purple-200 outline-hidden text-sm"
                />
              </div>
            )}
          </div>

          {/* Wallet Balance Verification */}
          <div className={`p-3 rounded-2xl border ${isInsufficient ? 'bg-rose-50 border-rose-200' : 'bg-purple-50 border-purple-200'}`}>
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 font-bold text-slate-700">
                <Wallet className="w-4 h-4 text-purple-600" />
                Wallet Balance:
              </span>
              <span className="font-extrabold text-sm font-gaming text-slate-900">
                ৳{currentBalance}
              </span>
            </div>

            {isInsufficient ? (
              <div className="mt-2 pt-2 border-t border-rose-200/80 flex items-center justify-between text-xs text-rose-800">
                <span className="flex items-center gap-1 text-[11px] font-medium">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                  Short by ৳{entryFee - currentBalance}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsJoinModalOpen(false);
                    setIsWalletModalOpen(true);
                  }}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs"
                >
                  Deposit Now
                </button>
              </div>
            ) : (
              <div className="mt-1 text-[11px] text-purple-800">
                After joining, remaining balance will be: <strong>৳{currentBalance - entryFee}</strong>
              </div>
            )}
          </div>

          {/* Action Button */}
          <button
            type="submit"
            disabled={isSubmitting || isInsufficient}
            className={`w-full py-3 rounded-xl font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 ${
              isInsufficient
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-linear-to-r from-purple-700 via-indigo-600 to-purple-800 text-white hover:opacity-95'
            }`}
          >
            {isSubmitting ? (
              <span>Registering...</span>
            ) : (
              <>
                <span>Confirm & Join Match</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
