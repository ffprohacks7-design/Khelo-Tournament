import React from 'react';
import { useApp } from '../../context/AppContext';
import { GameMode } from '../../types';
import { Swords, Flame, Skull, Users, Shield, Gift, Target } from 'lucide-react';

interface ModeItem {
  id: GameMode;
  title: string;
  image: string;
  fallbackGradient: string;
  icon: React.ReactNode;
  tag?: string;
}

const GAME_MODES: ModeItem[] = [
  {
    id: 'BR Match',
    title: 'BR MATCH',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-blue-600 to-indigo-900',
    icon: <Swords className="w-4 h-4 text-cyan-400" />,
    tag: 'POPULAR'
  },
  {
    id: 'BR Survival',
    title: 'BR SURVIVAL',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-amber-600 to-red-900',
    icon: <Flame className="w-4 h-4 text-amber-400" />,
    tag: 'SOLO'
  },
  {
    id: 'Clash Squad',
    title: 'Clash Squad',
    image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-purple-600 to-pink-900',
    icon: <Users className="w-4 h-4 text-purple-300" />,
    tag: '4 VS 4'
  },
  {
    id: 'CS 2 VS 2',
    title: 'CS 2 VS 2',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-cyan-600 to-blue-900',
    icon: <Shield className="w-4 h-4 text-cyan-300" />,
    tag: 'DUO'
  },
  {
    id: 'Lone Wolf',
    title: 'LONE WOLF',
    image: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-slate-700 to-slate-900',
    icon: <Skull className="w-4 h-4 text-rose-400" />,
    tag: '1 VS 1'
  },
  {
    id: 'Free Match',
    title: 'Free Match',
    image: 'https://images.unsplash.com/photo-1612287232230-675276e0ffc7?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-emerald-600 to-teal-900',
    icon: <Gift className="w-4 h-4 text-emerald-300" />,
    tag: '৳0 ENTRY'
  },
  {
    id: 'Custom Room',
    title: 'Custom Room',
    image: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=600&q=80',
    fallbackGradient: 'from-violet-600 to-purple-950',
    icon: <Target className="w-4 h-4 text-yellow-300" />,
    tag: 'PRO'
  }
];

export const GameModeGrid: React.FC = () => {
  const { tournaments, selectedCategory, setSelectedCategory, setActiveTab } = useApp();

  const getMatchCount = (mode: GameMode) => {
    return tournaments.filter((t) => t.gameMode === mode).length;
  };

  const handleSelectMode = (mode: GameMode) => {
    if (selectedCategory === mode) {
      setSelectedCategory('ALL');
    } else {
      setSelectedCategory(mode);
    }
  };

  return (
    <div className="px-3 pt-4">
      {/* Category Section Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-4 bg-purple-600 rounded-full"></div>
          <h2 className="text-base sm:text-lg font-black tracking-wider text-slate-800 uppercase font-gaming">
            FREE FIRE
          </h2>
          <span className="text-xs bg-slate-200/80 text-slate-700 font-bold px-2 py-0.5 rounded-full">
            {tournaments.length} Matches
          </span>
        </div>

        {selectedCategory !== 'ALL' && (
          <button
            onClick={() => setSelectedCategory('ALL')}
            className="text-xs font-bold text-purple-600 hover:text-purple-800 bg-purple-50 px-2 py-0.5 rounded-md"
          >
            Show All
          </button>
        )}
      </div>

      {/* 2-Column Grid matching reference image */}
      <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
        {GAME_MODES.map((item) => {
          const count = getMatchCount(item.id);
          const isSelected = selectedCategory === item.id;

          return (
            <div
              key={item.id}
              onClick={() => handleSelectMode(item.id)}
              className={`cursor-pointer group relative flex flex-col rounded-2xl overflow-hidden border transition-all duration-200 bg-white shadow-xs hover:shadow-md ${
                isSelected
                  ? 'border-purple-600 ring-2 ring-purple-500/40 transform -translate-y-0.5'
                  : 'border-slate-200/80 hover:border-purple-300'
              }`}
            >
              {/* Image Preview Container */}
              <div className="relative h-28 sm:h-32 w-full overflow-hidden bg-slate-900">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Visual Gradient overlay */}
                <div className="absolute inset-0 bg-linear-to-t from-slate-950/80 via-transparent to-black/30" />

                {/* Top Tag */}
                {item.tag && (
                  <div className="absolute top-2 left-2 z-10">
                    <span className="bg-slate-900/80 backdrop-blur-md text-[10px] font-black tracking-wider text-yellow-400 px-2 py-0.5 rounded-md border border-yellow-400/30 uppercase font-gaming">
                      {item.tag}
                    </span>
                  </div>
                )}

                {/* Center / Bottom Badge */}
                <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-white">
                    <div className="p-1 rounded-md bg-white/20 backdrop-blur-md">
                      {item.icon}
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-white/90 bg-black/50 backdrop-blur-md px-2 py-0.5 rounded-md">
                    FF
                  </span>
                </div>
              </div>

              {/* Bottom White/Light Footer Bar matching reference image */}
              <div className="p-2.5 bg-slate-50 border-t border-slate-100 flex flex-col">
                <span className="font-extrabold text-xs sm:text-sm text-slate-800 tracking-tight font-gaming uppercase group-hover:text-purple-700 transition-colors">
                  {item.title}
                </span>
                <span className="text-[11px] font-medium text-slate-500 mt-0.5">
                  {count} {count === 1 ? 'match' : 'matches'} found
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
