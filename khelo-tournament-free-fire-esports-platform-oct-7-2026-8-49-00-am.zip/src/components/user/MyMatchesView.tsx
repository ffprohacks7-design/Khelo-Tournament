import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Calendar, Clock, Trophy, Key, Lock, CheckCircle2, ChevronRight, Copy, Check, Swords } from 'lucide-react';
import { Tournament } from '../../types';

export const MyMatchesView: React.FC = () => {
  const { 
    currentUser, 
    tournaments, 
    results, 
    setSelectedTournament, 
    setIsDetailOpen, 
    showToast,
    setActiveTab,
    t 
  } = useApp();

  const [filterTab, setFilterTab] = useState<'all' | 'live' | 'upcoming' | 'completed'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedPass, setCopiedPass] = useState<string | null>(null);

  // Filter tournaments that user has joined or demo matches
  // For demo experience, if user is RakibGaming (USR-89421) or has joined matches
  const joinedTournaments = tournaments.filter((trn) => {
    // In our seed data, TRN-101, TRN-104, TRN-105 were joined by Rakib
    if (currentUser?.id === 'USR-89421') {
      return ['TRN-101', 'TRN-104', 'TRN-105'].includes(trn.id);
    }
    // Also include any tournament where joinedSlots > 0 for demo preview
    return trn.joinedSlots > 0;
  });

  const filteredMatches = joinedTournaments.filter((trn) => {
    if (filterTab === 'live') return trn.status === 'Live';
    if (filterTab === 'upcoming') return trn.status === 'Upcoming' || trn.status === 'Registration Open';
    if (filterTab === 'completed') return trn.status === 'Completed';
    return true;
  });

  const copyText = (text: string, id: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      setCopiedPass(id);
      setTimeout(() => setCopiedPass(null), 2000);
    }
    showToast(`${type === 'id' ? 'Room ID' : 'Password'} copied!`, 'success');
  };

  const getResultForMatch = (trnId: string) => {
    return results.find((r) => r.tournamentId === trnId && (r.userId === currentUser?.id || r.playerName.includes('RAKIB')));
  };

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-800 font-gaming uppercase tracking-wide">
            {t.myMatches}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Your registered Free Fire tournament matches and credentials.
          </p>
        </div>

        <span className="bg-purple-100 text-purple-800 font-extrabold text-xs px-2.5 py-1 rounded-full">
          {filteredMatches.length} Matches
        </span>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-200/80 p-1 rounded-2xl gap-1 text-xs font-bold text-slate-600">
        <button
          onClick={() => setFilterTab('all')}
          className={`flex-1 py-2 rounded-xl transition-all ${filterTab === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
        >
          All
        </button>
        <button
          onClick={() => setFilterTab('live')}
          className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1 ${filterTab === 'live' ? 'bg-white text-rose-600 shadow-xs' : 'hover:text-slate-900'}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
          Live
        </button>
        <button
          onClick={() => setFilterTab('upcoming')}
          className={`flex-1 py-2 rounded-xl transition-all ${filterTab === 'upcoming' ? 'bg-white text-purple-700 shadow-xs' : 'hover:text-slate-900'}`}
        >
          Upcoming
        </button>
        <button
          onClick={() => setFilterTab('completed')}
          className={`flex-1 py-2 rounded-xl transition-all ${filterTab === 'completed' ? 'bg-white text-emerald-700 shadow-xs' : 'hover:text-slate-900'}`}
        >
          Completed
        </button>
      </div>

      {/* Matches List */}
      {filteredMatches.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 shadow-xs space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto">
            <Swords className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-sm text-slate-800">No matches found</h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            You haven't joined any matches in this category yet. Explore tournaments now!
          </p>
          <button
            onClick={() => setActiveTab('play')}
            className="px-4 py-2 rounded-xl bg-purple-700 text-white font-bold text-xs hover:bg-purple-800 transition-colors"
          >
            Browse Tournaments
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredMatches.map((match) => {
            const result = getResultForMatch(match.id);

            return (
              <div
                key={match.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden transition-all hover:border-purple-300"
              >
                {/* Match Card Top */}
                <div className="p-3.5 flex items-start justify-between gap-3 border-b border-slate-100">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-purple-100 text-purple-800 text-[10px] font-black px-2 py-0.5 rounded-md uppercase font-gaming">
                        {match.gameMode}
                      </span>
                      <span className="text-[11px] font-bold text-slate-500">
                        {match.matchType} • {match.map}
                      </span>
                    </div>
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-900 font-gaming">
                      {match.title}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {match.matchDate}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-800 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-purple-600" />
                        {match.matchTime}
                      </span>
                    </div>
                  </div>

                  {/* Status */}
                  <div>
                    {match.status === 'Live' ? (
                      <span className="bg-rose-500 text-white font-bold text-[10px] px-2 py-0.5 rounded-full uppercase flex items-center gap-1 animate-pulse">
                        <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                        LIVE
                      </span>
                    ) : match.status === 'Completed' ? (
                      <span className="bg-slate-100 text-slate-700 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
                        FINISHED
                      </span>
                    ) : (
                      <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
                        CONFIRMED
                      </span>
                    )}
                  </div>
                </div>

                {/* Match Credentials / Results Bar */}
                <div className="p-3 bg-slate-50">
                  {match.isRoomPublished ? (
                    <div className="bg-slate-900 rounded-xl p-3 text-white border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                          <Key className="w-4 h-4 text-emerald-300" />
                        </div>
                        <div>
                          <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                            ROOM CREDENTIALS READY
                          </div>
                          <div className="flex items-center gap-4 text-xs font-mono font-bold mt-0.5">
                            <span className="text-slate-200">
                              ID: <strong className="text-white text-sm">{match.roomId || '84729104'}</strong>
                            </span>
                            <span className="text-slate-200">
                              Pass: <strong className="text-yellow-300 text-sm">{match.roomPassword || '8899'}</strong>
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => copyText(match.roomId || '', match.id, 'id')}
                          className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold text-slate-200 flex items-center gap-1 transition-colors"
                        >
                          {copiedId === match.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          Copy ID
                        </button>
                        <button
                          onClick={() => copyText(match.roomPassword || '', match.id, 'pass')}
                          className="px-2.5 py-1 rounded-lg bg-yellow-400 text-slate-950 text-xs font-bold flex items-center gap-1 hover:bg-yellow-300 transition-colors"
                        >
                          {copiedPass === match.id ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <Copy className="w-3.5 h-3.5" />}
                          Copy Pass
                        </button>
                      </div>
                    </div>
                  ) : match.status === 'Completed' && result ? (
                    <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-200 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-amber-500" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">
                            Rank #{result.rank} • {result.kills} Kills
                          </p>
                          <p className="text-[10px] text-slate-500">
                            Score: {result.score} pts
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-emerald-700 font-bold block">Prize Won</span>
                        <span className="font-black text-sm text-emerald-700 font-gaming">৳{result.prize}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                        Room ID & password will unlock 15m before match.
                      </span>
                      <button
                        onClick={() => {
                          setSelectedTournament(match);
                          setIsDetailOpen(true);
                        }}
                        className="text-purple-600 font-bold hover:underline flex items-center gap-0.5"
                      >
                        Details <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
