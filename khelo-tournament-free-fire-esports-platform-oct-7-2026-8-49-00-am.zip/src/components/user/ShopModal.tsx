import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles, Gem, Check, ShieldCheck, Zap } from 'lucide-react';

interface DiamondPackage {
  id: string;
  diamonds: number;
  bonus: number;
  price: number;
  badge?: string;
}

const PACKAGES: DiamondPackage[] = [
  { id: 'pkg-1', diamonds: 115, bonus: 0, price: 85, badge: 'STARTER' },
  { id: 'pkg-2', diamonds: 240, bonus: 20, price: 165, badge: 'POPULAR' },
  { id: 'pkg-3', diamonds: 610, bonus: 50, price: 410, badge: 'BEST VALUE' },
  { id: 'pkg-4', diamonds: 1240, bonus: 120, price: 820 },
  { id: 'pkg-5', diamonds: 2530, bonus: 250, price: 1640, badge: 'PRO BUNDLE' },
];

export const ShopModal: React.FC = () => {
  const { isShopModalOpen, setIsShopModalOpen, currentUser, showToast } = useApp();
  const [selectedPkg, setSelectedPkg] = useState<DiamondPackage>(PACKAGES[1]);
  const [ffUid, setFfUid] = useState(currentUser?.ffUid || '');
  const [isOrdering, setIsOrdering] = useState(false);

  if (!isShopModalOpen) return null;

  const handleOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ffUid.trim()) {
      showToast('Please enter your Free Fire UID', 'error');
      return;
    }

    setIsOrdering(true);
    setTimeout(() => {
      setIsOrdering(false);
      setIsShopModalOpen(false);
      showToast(`Top-up order for ${selectedPkg.diamonds + selectedPkg.bonus} 💎 placed! Admin will credit your UID within 10 minutes.`, 'success');
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-linear-to-r from-cyan-600 via-blue-600 to-indigo-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-400 text-blue-950 flex items-center justify-center font-black shadow-md">
              <Gem className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base font-gaming tracking-wide">
                FREE FIRE DIAMOND SHOP
              </h3>
              <p className="text-[11px] text-cyan-100">
                Direct in-game top up via UID • 100% safe & instant
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsShopModalOpen(false)}
            className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleOrder} className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* UID Input */}
          <div>
            <label className="block font-bold text-slate-700 mb-1 uppercase">
              Free Fire Player UID:
            </label>
            <input
              type="text"
              required
              value={ffUid}
              onChange={(e) => setFfUid(e.target.value)}
              placeholder="e.g. 839201948"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-cyan-600 outline-hidden font-mono text-sm"
            />
            <p className="text-[10px] text-slate-400 mt-0.5">Diamonds will be directly sent to this Free Fire account.</p>
          </div>

          {/* Package Grid */}
          <div>
            <label className="block font-bold text-slate-700 mb-2 uppercase">
              Select Diamond Package:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {PACKAGES.map((pkg) => {
                const isSelected = selectedPkg.id === pkg.id;

                return (
                  <div
                    key={pkg.id}
                    onClick={() => setSelectedPkg(pkg)}
                    className={`cursor-pointer relative p-3 rounded-2xl border text-center transition-all ${
                      isSelected
                        ? 'border-cyan-500 bg-cyan-50/50 ring-2 ring-cyan-400/40 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                    }`}
                  >
                    {pkg.badge && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-cyan-500 text-white font-black text-[9px] px-2 py-0.2 rounded-full uppercase font-gaming shadow-xs">
                        {pkg.badge}
                      </span>
                    )}

                    <div className="flex items-center justify-center gap-1 text-cyan-600 mt-1 mb-1">
                      <Gem className="w-4 h-4" />
                      <span className="font-black text-base text-slate-900 font-gaming">
                        {pkg.diamonds}
                      </span>
                    </div>

                    {pkg.bonus > 0 && (
                      <span className="text-[10px] text-emerald-600 font-bold block">
                        +{pkg.bonus} Bonus 💎
                      </span>
                    )}

                    <span className="font-extrabold text-sm text-purple-700 block mt-1 font-gaming">
                      ৳{pkg.price}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Order Summary & Security */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5 text-slate-700">
            <div className="flex justify-between font-bold">
              <span>Selected Amount:</span>
              <span className="text-cyan-700 font-gaming font-black">{selectedPkg.diamonds + selectedPkg.bonus} Diamonds</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Price:</span>
              <span className="text-purple-700 font-gaming font-black text-sm">৳{selectedPkg.price}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-emerald-700 pt-1 border-t border-slate-200">
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              <span>Garena Authorized Top-up Partner. No password needed.</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={isOrdering}
            className="w-full py-3 rounded-xl bg-linear-to-r from-cyan-600 via-blue-600 to-indigo-700 hover:opacity-95 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95"
          >
            {isOrdering ? 'Processing Order...' : `Buy Now for ৳${selectedPkg.price}`}
          </button>
        </form>

      </div>
    </div>
  );
};
