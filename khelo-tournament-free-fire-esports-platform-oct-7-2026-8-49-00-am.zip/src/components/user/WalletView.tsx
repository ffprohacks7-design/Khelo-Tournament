import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Wallet, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Trophy, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  X,
  CreditCard 
} from 'lucide-react';
import { api } from '../../services/api';

export const WalletView: React.FC = () => {
  const { currentUser, transactions, refreshAll, showToast, isWalletModalOpen, setIsWalletModalOpen, t } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'deposits' | 'withdrawals' | 'rewards'>('all');
  const [modalMode, setModalMode] = useState<'none' | 'deposit' | 'withdraw'>('none');

  // Form states
  const [amount, setAmount] = useState('100');
  const [method, setMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');
  const [accountNumber, setAccountNumber] = useState(currentUser?.phone || '');
  const [trxId, setTrxId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const userTransactions = transactions.filter((tx) => !currentUser || tx.userId === currentUser.id);

  const filteredTxns = userTransactions.filter((tx) => {
    if (activeTab === 'deposits') return tx.type === 'Deposit';
    if (activeTab === 'withdrawals') return tx.type === 'Withdrawal';
    if (activeTab === 'rewards') return tx.type === 'Match Reward' || tx.type === 'Admin Bonus';
    return true;
  });

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const num = Number(amount);
    if (!num || num < 20) {
      showToast('Minimum deposit is ৳20', 'error');
      return;
    }
    if (!accountNumber.trim()) {
      showToast('Enter your mobile payment number', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.deposit({
        userId: currentUser.id,
        amount: num,
        paymentMethod: method,
        accountNumber: accountNumber.trim(),
        transactionRef: trxId.trim() || undefined,
      });
      showToast('Deposit request submitted! Admin will verify and credit your balance.', 'success');
      setModalMode('none');
      setTrxId('');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Deposit failed', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const num = Number(amount);
    if (!num || num < 50) {
      showToast('Minimum withdrawal is ৳50', 'error');
      return;
    }
    if (num > currentUser.walletBalance) {
      showToast('Insufficient wallet balance', 'error');
      return;
    }
    if (!accountNumber.trim()) {
      showToast('Enter your payment account number', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.withdraw({
        userId: currentUser.id,
        amount: num,
        paymentMethod: method,
        accountNumber: accountNumber.trim(),
      });
      showToast('Withdrawal request submitted! Processing time: 1-2 hours.', 'success');
      setModalMode('none');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Withdrawal failed', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-2xl mx-auto">
      {/* Wallet Card */}
      <div className="relative overflow-hidden bg-linear-to-br from-purple-900 via-indigo-900 to-slate-950 rounded-3xl p-5 text-white shadow-xl border border-purple-500/30">
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-yellow-400 text-slate-950 flex items-center justify-center font-black">
              ৳
            </div>
            <div>
              <span className="text-xs text-purple-200 font-bold block uppercase tracking-wider">
                TOURNAMENT WALLET
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                ID: {currentUser?.id || 'GUEST'}
              </span>
            </div>
          </div>

          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            SECURED
          </span>
        </div>

        {/* Balance Numbers */}
        <div className="py-4 flex items-end justify-between">
          <div>
            <span className="text-xs text-slate-300 font-medium block">
              Current Available Balance
            </span>
            <div className="text-3xl sm:text-4xl font-black font-gaming tracking-wide text-white flex items-baseline gap-1 mt-0.5">
              <span className="text-yellow-400 text-2xl font-sans">৳</span>
              <span>{currentUser?.walletBalance ?? 0}</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400 block font-medium">Total Winnings</span>
            <span className="text-base sm:text-lg font-black text-emerald-400 font-gaming">
              ৳{currentUser?.totalEarnings ?? 0}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            onClick={() => setModalMode('deposit')}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-linear-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-extrabold text-xs shadow-md shadow-emerald-950/40 font-gaming transition-all active:scale-95"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>ADD MONEY</span>
          </button>

          <button
            onClick={() => setModalMode('withdraw')}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-linear-to-r from-amber-500 to-orange-600 hover:opacity-95 text-white font-extrabold text-xs shadow-md shadow-orange-950/40 font-gaming transition-all active:scale-95"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>WITHDRAW</span>
          </button>
        </div>
      </div>

      {/* Transactions Section */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-extrabold text-sm text-slate-900 font-gaming uppercase tracking-wide">
            {t.recentTransactions}
          </h3>
          <span className="text-xs font-bold text-slate-500">
            {filteredTxns.length} records
          </span>
        </div>

        {/* Filter Pills */}
        <div className="px-3 py-2 bg-slate-50 border-b border-slate-100 flex gap-1 text-[11px] font-bold text-slate-600 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1 rounded-lg transition-colors shrink-0 ${activeTab === 'all' ? 'bg-purple-700 text-white' : 'hover:bg-slate-200'}`}
          >
            All
          </button>
          <button
            onClick={() => setActiveTab('rewards')}
            className={`px-3 py-1 rounded-lg transition-colors shrink-0 ${activeTab === 'rewards' ? 'bg-purple-700 text-white' : 'hover:bg-slate-200'}`}
          >
            Rewards & Wins
          </button>
          <button
            onClick={() => setActiveTab('deposits')}
            className={`px-3 py-1 rounded-lg transition-colors shrink-0 ${activeTab === 'deposits' ? 'bg-purple-700 text-white' : 'hover:bg-slate-200'}`}
          >
            Deposits
          </button>
          <button
            onClick={() => setActiveTab('withdrawals')}
            className={`px-3 py-1 rounded-lg transition-colors shrink-0 ${activeTab === 'withdrawals' ? 'bg-purple-700 text-white' : 'hover:bg-slate-200'}`}
          >
            Withdrawals
          </button>
        </div>

        {/* List */}
        {filteredTxns.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500">
            No transactions found yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredTxns.map((tx) => {
              const isPositive = tx.amount > 0;

              return (
                <div key={tx.id} className="p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.type === 'Match Reward' ? 'bg-amber-100 text-amber-700' :
                      tx.type === 'Deposit' ? 'bg-emerald-100 text-emerald-700' :
                      tx.type === 'Withdrawal' ? 'bg-rose-100 text-rose-700' :
                      'bg-purple-100 text-purple-700'
                    }`}>
                      {tx.type === 'Match Reward' ? <Trophy className="w-4 h-4" /> :
                       tx.type === 'Deposit' ? <ArrowDownLeft className="w-4 h-4" /> :
                       tx.type === 'Withdrawal' ? <ArrowUpRight className="w-4 h-4" /> :
                       <CreditCard className="w-4 h-4" />}
                    </div>

                    <div>
                      <h4 className="font-bold text-slate-900 leading-tight">
                        {tx.description}
                      </h4>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        {tx.date} • {tx.time} {tx.paymentMethod ? `• ${tx.paymentMethod}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`font-black text-sm font-gaming ${isPositive ? 'text-emerald-600' : 'text-slate-900'}`}>
                      {isPositive ? `+৳${tx.amount}` : `-৳${Math.abs(tx.amount)}`}
                    </span>
                    <span className={`block text-[10px] font-bold ${
                      tx.status === 'Approved' ? 'text-emerald-600' :
                      tx.status === 'Pending' ? 'text-amber-600' : 'text-rose-600'
                    }`}>
                      {tx.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Deposit / Withdraw Modal */}
      {modalMode !== 'none' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95">
            <div className={`p-4 text-white flex items-center justify-between ${modalMode === 'deposit' ? 'bg-emerald-700' : 'bg-amber-700'}`}>
              <h3 className="font-black text-base font-gaming tracking-wide uppercase">
                {modalMode === 'deposit' ? 'DEPOSIT MONEY (BKASH / NAGAD)' : 'WITHDRAW REWARD WINNINGS'}
              </h3>
              <button
                onClick={() => setModalMode('none')}
                className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={modalMode === 'deposit' ? handleDepositSubmit : handleWithdrawSubmit} className="p-4 sm:p-5 space-y-4 text-xs">
              {/* Payment Method Selector */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5 uppercase">
                  Select Gateway:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['bKash', 'Nagad', 'Rocket'] as const).map((m) => (
                    <button
                      type="button"
                      key={m}
                      onClick={() => setMethod(m)}
                      className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                        method === m
                          ? 'border-purple-600 bg-purple-50 text-purple-800 ring-2 ring-purple-300'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="block font-bold text-slate-700 mb-1 uppercase">
                  Amount (BDT ৳):
                </label>
                <div className="flex gap-2 mb-2">
                  {['50', '100', '250', '500'].map((preset) => (
                    <button
                      type="button"
                      key={preset}
                      onClick={() => setAmount(preset)}
                      className={`flex-1 py-1 rounded-lg border text-xs font-bold ${
                        amount === preset ? 'bg-purple-700 text-white border-purple-700' : 'border-slate-200 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      ৳{preset}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  required
                  min={modalMode === 'deposit' ? 20 : 50}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-gaming text-base font-bold"
                />
              </div>

              {/* Account Number */}
              <div>
                <label className="block font-bold text-slate-700 mb-1 uppercase">
                  {method} Mobile Number:
                </label>
                <input
                  type="text"
                  required
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="e.g. 01712345678"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-mono"
                />
              </div>

              {/* TrxID if deposit */}
              {modalMode === 'deposit' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1 uppercase">
                    Transaction TrxID (from SMS):
                  </label>
                  <input
                    type="text"
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    placeholder="e.g. 9X28KA7L0"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-600 outline-hidden font-mono uppercase"
                  />
                  <div className="mt-2 p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
                    💡 Send Money to Official {method} Merchant: <strong>01700-000000</strong>, then enter TrxID above.
                  </div>
                </div>
              )}

              {modalMode === 'withdraw' && (
                <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px] leading-relaxed">
                  🛡️ Payouts are manually approved by Admin to protect match integrity. Minimum payout: ৳50.
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-3 rounded-xl font-black text-sm uppercase tracking-wider font-gaming shadow-md text-white transition-all active:scale-95 ${
                  modalMode === 'deposit' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-600 hover:bg-amber-700'
                }`}
              >
                {isSubmitting ? 'Processing...' : modalMode === 'deposit' ? 'Submit Deposit Request' : 'Submit Withdrawal Request'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
