import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Send, Trophy, Sparkles, ChevronRight, Zap } from 'lucide-react';

export const BannerSlider: React.FC = () => {
  const { banners, settings, setIsSupportModalOpen, setIsShopModalOpen, setActiveTab } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);

  // Active banners
  const activeBanners = banners.filter(b => b.isActive);

  // Auto-slide
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  const handleBannerClick = (type: string, url?: string) => {
    if (type === 'telegram') {
      setIsSupportModalOpen(true);
    } else if (type === 'shop') {
      setIsShopModalOpen(true);
    } else if (type === 'tournament') {
      setActiveTab('play');
    } else if (url && url.startsWith('http')) {
      window.open(url, '_blank');
    }
  };

  if (activeBanners.length === 0) return null;

  return (
    <div className="px-3 pt-3">
      {/* Slider Container */}
      <div className="relative overflow-hidden rounded-2xl shadow-md border border-slate-200/60 bg-linear-to-r from-blue-700 via-indigo-600 to-purple-800 text-white min-h-[175px] sm:min-h-[190px]">
        {/* Dynamic Slide */}
        {activeBanners.map((banner, idx) => {
          if (idx !== currentIndex) return null;

          return (
            <div
              key={banner.id}
              onClick={() => handleBannerClick(banner.actionType, banner.actionUrl)}
              className="relative cursor-pointer p-4 h-full flex items-center justify-between transition-all duration-500 overflow-hidden"
            >
              {/* Background Glow & Pattern */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-400/20 via-transparent to-black/30 pointer-events-none" />
              <div className="absolute -right-6 -bottom-6 w-48 h-48 bg-purple-500/30 rounded-full blur-2xl pointer-events-none" />

              {/* Left / Center Content */}
              <div className="relative z-10 max-w-[62%] sm:max-w-[65%] flex flex-col justify-center space-y-1.5">
                {banner.actionType === 'telegram' ? (
                  <>
                    <div className="inline-flex items-center gap-1 bg-cyan-400/25 border border-cyan-300/40 text-cyan-200 text-[10px] font-bold px-2 py-0.5 rounded-full w-fit tracking-wider">
                      <Send className="w-2.5 h-2.5" />
                      OFFICIAL COMMUNITY
                    </div>

                    <h2 className="text-xl sm:text-2xl font-black italic tracking-wide text-white drop-shadow-md leading-tight font-gaming">
                      JOIN US <span className="text-cyan-300">ON</span><br />
                      <span className="text-white drop-shadow-[0_2px_10px_rgba(34,211,238,0.5)]">TELEGRAM</span>
                    </h2>

                    {/* Telegram username badge matching reference */}
                    <div className="flex flex-col gap-1 pt-1">
                      <div className="inline-flex items-center gap-1.5 bg-white text-blue-900 font-extrabold text-xs px-2.5 py-1 rounded-full shadow-md w-fit border border-blue-200">
                        <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white">
                          <Send className="w-2.5 h-2.5 -translate-x-0.5" />
                        </div>
                        <span className="text-[11px] font-mono tracking-tight">{settings?.telegramChannelName || '@khelobangladesh_live'}</span>
                      </div>

                      <div className="text-[10px] text-cyan-200 font-bold tracking-wider uppercase flex items-center gap-1">
                        <span>« CLICK HERE FOR JOIN »</span>
                      </div>
                    </div>
                  </>
                ) : banner.actionType === 'shop' ? (
                  <>
                    <div className="inline-flex items-center gap-1 bg-amber-400/25 border border-amber-300/40 text-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full w-fit">
                      <Zap className="w-2.5 h-2.5" />
                      INSTANT TOP-UP
                    </div>
                    <h2 className="text-xl sm:text-2xl font-black italic tracking-wide text-white drop-shadow-md leading-tight font-gaming">
                      FREE FIRE <span className="text-yellow-300">DIAMONDS</span>
                    </h2>
                    <p className="text-xs text-blue-100 font-medium">
                      Lowest rates via bKash & Nagad in Bangladesh!
                    </p>
                    <div className="pt-1">
                      <span className="inline-flex items-center gap-1 bg-yellow-400 text-slate-950 font-bold text-xs px-3 py-1 rounded-full shadow-md">
                        Top-up Now <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="inline-flex items-center gap-1 bg-emerald-400/25 border border-emerald-300/40 text-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full w-fit">
                      <Trophy className="w-2.5 h-2.5" />
                      SPECIAL EVENT
                    </div>
                    <h2 className="text-lg sm:text-xl font-black italic tracking-wide text-white drop-shadow-md leading-tight font-gaming">
                      {banner.title}
                    </h2>
                    <p className="text-xs text-blue-100 font-medium line-clamp-2">
                      {banner.subtitle || 'Join top tournament brackets and win cash prizes!'}
                    </p>
                    <div className="pt-1">
                      <span className="inline-flex items-center gap-1 bg-white text-purple-900 font-extrabold text-xs px-3 py-1 rounded-full shadow-md">
                        Enter Battle <Sparkles className="w-3 h-3 text-amber-500" />
                      </span>
                    </div>
                  </>
                )}
              </div>

              {/* Right: Mascot / Image illustration matching reference design */}
              <div className="relative z-10 w-[38%] sm:w-[35%] flex justify-end items-center pr-1">
                {banner.actionType === 'telegram' ? (
                  <div className="relative flex flex-col items-center">
                    {/* Tiger Mascot Avatar with esports badge */}
                    <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-linear-to-tr from-amber-500 to-orange-400 p-1 shadow-2xl rotate-2 ring-2 ring-white/50 flex items-center justify-center overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80"
                        alt="Esports Mascot"
                        className="w-full h-full object-cover rounded-xl scale-110"
                      />
                    </div>
                    <span className="absolute -bottom-2 bg-yellow-400 text-slate-900 font-black text-[9px] px-2 py-0.5 rounded-full shadow-md uppercase font-gaming">
                      KHELO FF
                    </span>
                  </div>
                ) : (
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden shadow-2xl ring-2 ring-white/40">
                    <img
                      src={banner.imageUrl}
                      alt={banner.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform"
                    />
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Carousel Dots indicator matching screenshot */}
        <div className="absolute bottom-2 left-0 right-0 z-20 flex justify-center items-center gap-1.5">
          {activeBanners.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={(e) => {
                e.stopPropagation();
                setCurrentIndex(dotIdx);
              }}
              className={`transition-all duration-300 rounded-full ${
                dotIdx === currentIndex
                  ? 'w-5 h-1.5 bg-amber-400 ring-1 ring-amber-300'
                  : 'w-1.5 h-1.5 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`Slide ${dotIdx + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
