import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Trophy, Medal, Award, Flame, Crosshair, Users, ChevronDown } from 'lucide-react';

export const ResultsView: React.FC = () => {
  const { results, tournaments, t } = useApp();

  const completedTournaments = tournaments.filter((t) => t.status === 'Completed' || t.id === 'TRN-105');
  const [selectedTrnId, setSelectedTrnId] = useState<string>(
    completedTournaments[0]?.id || 'TRN-105'
  );

  const selectedTournament = tournaments.find((t) => t.id === selectedTrnId);
  const matchResults = results.filter((r) => r.tournamentId === selectedTrnId);

  // Sort by rank
  const sortedResults = [...matchResults].sort((a, b) => a.rank - b.rank);
  const top1 = sortedResults.find((r) => r.rank === 1);
  const top2 = sortedResults.find((r) => r.rank === 2);
  const top3 = sortedResults.find((r) => r.rank === 3);

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-800 font-gaming uppercase tracking-wide">
            {t.results} & Leaderboard
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Official match rankings, kill scores, and distributed prizes.
          </p>
        </div>
        <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
          <Trophy className="w-4 h-4" />
        </div>
      </div>

      {/* Tournament Selector Dropdown */}
      <div className="relative">
        <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
          Select Completed Tournament:
        </label>
        <div className="relative">
          <select
            value={selectedTrnId}
            onChange={(e) => setSelectedTrnId(e.target.value)}
            className="w-full appearance-none bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 focus:outline-hidden focus:border-purple-600 shadow-xs"
          >
            {completedTournaments.map((trn) => (
              <option key={trn.id} value={trn.id}>
                {trn.title} ({trn.gameMode} - {trn.matchDate})
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
        </div>
      </div>

      {/* Podium for Top 3 (if available) */}
      {top1 && (
        <div className="bg-linear-to-b from-indigo-950 via-slate-900 to-purple-950 rounded-3xl p-4 text-white shadow-lg border border-purple-500/30">
          <div className="text-center pb-2">
            <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-widest font-gaming">
              TOURNAMENT CHAMPIONS
            </span>
            <h3 className="text-sm sm:text-base font-black text-white font-gaming">
              {selectedTournament?.title}
            </h3>
          </div>

          {/* 3 Pillars Layout */}
          <div className="grid grid-cols-3 gap-2 items-end pt-4 pb-2 text-center">
            {/* Rank 2 */}
            <div className="flex flex-col items-center">
              {top2 ? (
                <>
                  <div className="w-12 h-12 rounded-full border-2 border-slate-300 bg-slate-800 flex items-center justify-center shadow-md mb-1 relative">
                    <span className="text-xs font-bold font-gaming">#2</span>
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-slate-300 text-slate-900 rounded-full text-[10px] font-black flex items-center justify-center">
                      🥈
                    </span>
                  </div>
                  <span className="text-xs font-bold text-slate-200 truncate max-w-[85px] block font-gaming">
                    {top2.playerName}
                  </span>
                  <span className="text-[10px] text-slate-400">{top2.kills} Kills</span>
                  <div className="mt-2 w-full bg-slate-800/80 rounded-t-xl py-2 px-1 border-t-2 border-slate-400">
                    <span className="text-[11px] font-black text-slate-200 font-gaming">৳{top2.prize}</span>
                  </div>
                </>
              ) : null}
            </div>

            {/* Rank 1 (Winner) */}
            <div className="flex flex-col items-center -translate-y-2">
              <div className="w-16 h-16 rounded-full border-2 border-amber-400 bg-amber-950/60 flex items-center justify-center shadow-xl mb-1 relative ring-4 ring-amber-400/20">
                <Trophy className="w-7 h-7 text-yellow-400 animate-bounce" />
                <span className="absolute -top-1.5 -right-1.5 w-6 h-6 bg-yellow-400 text-slate-950 rounded-full text-xs font-black flex items-center justify-center shadow-md">
                  👑
                </span>
              </div>
              <span className="text-xs sm:text-sm font-extrabold text-yellow-300 truncate max-w-[100px] block font-gaming">
                {top1.playerName}
              </span>
              <span className="text-[10px] text-yellow-200/80">{top1.kills} Kills • {top1.score} pts</span>
              <div className="mt-2 w-full bg-amber-500/20 rounded-t-xl py-3 px-1 border-t-2 border-yellow-400">
                <span className="text-xs font-black text-yellow-300 font-gaming">৳{top1.prize}</span>
              </div>
            </div>

            {/* Rank 3 */}
            <div className="flex flex-col items-center">
              {top3 ? (
                <>
                  <div className="w-12 h-12 rounded-full border-2 border-amber-600 bg-slate-800 flex items-center justify-center shadow-md mb-1 relative">
                    <span className="text-xs font-bold font-gaming">#3</span>
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-600 text-white rounded-full text-[10px] font-black flex items-center justify-center">
                      🥉
                    </span>
                  </div>
                  <span className="text-xs font-bold text-slate-200 truncate max-w-[85px] block font-gaming">
                    {top3.playerName}
                  </span>
                  <span className="text-[10px] text-slate-400">{top3.kills} Kills</span>
                  <div className="mt-2 w-full bg-slate-800/80 rounded-t-xl py-1.5 px-1 border-t-2 border-amber-600">
                    <span className="text-[11px] font-black text-amber-400 font-gaming">৳{top3.prize}</span>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs font-bold text-slate-600">
          <span>Match Standings</span>
          <span>{sortedResults.length} Entries</span>
        </div>

        {sortedResults.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            No results published yet for this match.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sortedResults.map((item) => (
              <div
                key={item.id}
                className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                    item.rank === 1 ? 'bg-amber-400 text-slate-950 font-black' :
                    item.rank === 2 ? 'bg-slate-300 text-slate-900 font-black' :
                    item.rank === 3 ? 'bg-amber-600 text-white font-black' :
                    'bg-slate-100 text-slate-600'
                  }`}>
                    {item.rank}
                  </span>

                  <div>
                    <h4 className="font-extrabold text-slate-900 font-gaming">
                      {item.playerName}
                    </h4>
                    <p className="text-[10px] text-slate-500 font-mono">
                      UID: {item.ffUid}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-right">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Kills</span>
                    <span className="font-bold text-slate-700 font-gaming">{item.kills}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Score</span>
                    <span className="font-bold text-slate-700 font-gaming">{item.score}</span>
                  </div>

                  <div className="min-w-[60px]">
                    <span className="text-[10px] text-emerald-600 block uppercase font-bold">Prize</span>
                    <span className="font-black text-sm text-emerald-700 font-gaming">
                      {item.prize > 0 ? `৳${item.prize}` : '—'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
