import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  User, 
  Trophy, 
  Gamepad2, 
  Flame, 
  TrendingUp, 
  Edit3, 
  Save, 
  LogOut, 
  ShieldCheck, 
  Phone, 
  Mail, 
  Hash, 
  Check 
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const { currentUser, updateUserProfile, logout, setViewMode, setIsAuthModalOpen, t } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [inGameName, setInGameName] = useState(currentUser?.inGameName || '');
  const [ffUid, setFfUid] = useState(currentUser?.ffUid || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');

  if (!currentUser) {
    return (
      <div className="p-8 text-center max-w-md mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto">
          <User className="w-8 h-8" />
        </div>
        <h3 className="font-bold text-base text-slate-800">You are not logged in</h3>
        <p className="text-xs text-slate-500">
          Sign in or create an account to view your Free Fire stats, rank, and tournament history.
        </p>
        <button
          onClick={() => setIsAuthModalOpen(true)}
          className="px-6 py-2.5 rounded-xl bg-purple-700 text-white font-bold text-xs hover:bg-purple-800 transition-colors"
        >
          Login or Register
        </button>
      </div>
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({
      name,
      inGameName,
      ffUid,
      phone,
      avatar,
    });
    setIsEditing(false);
  };

  const AVATAR_OPTIONS = [
    'https://api.dicebear.com/7.x/bottts/svg?seed=Rakib',
    'https://api.dicebear.com/7.x/bottts/svg?seed=Shadow',
    'https://api.dicebear.com/7.x/bottts/svg?seed=Apex',
    'https://api.dicebear.com/7.x/bottts/svg?seed=Viper',
    'https://api.dicebear.com/7.x/bottts/svg?seed=Cyber',
  ];

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-2xl mx-auto">
      {/* Profile Header Card */}
      <div className="relative overflow-hidden bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
          {/* Avatar with Ring */}
          <div className="relative group shrink-0">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-20 h-20 rounded-2xl bg-purple-50 object-cover border-2 border-purple-500 shadow-md"
            />
            <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white">
              PRO
            </span>
          </div>

          {/* Player Info */}
          <div className="flex-1 space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-lg sm:text-xl font-black text-slate-900 font-gaming tracking-wide">
                {currentUser.inGameName || currentUser.username}
              </h2>
              <span className="bg-purple-100 text-purple-800 text-[10px] font-black px-2 py-0.5 rounded-md uppercase font-gaming">
                {currentUser.role}
              </span>
            </div>

            <p className="text-xs text-slate-500 font-medium">
              {currentUser.name} • {currentUser.email}
            </p>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-1 text-xs">
              <div className="bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 font-mono text-[11px] text-slate-700">
                FF UID: <strong className="text-purple-700">{currentUser.ffUid}</strong>
              </div>
              <div className="bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 font-mono text-[11px] text-slate-700">
                USER ID: <strong className="text-slate-900">{currentUser.id}</strong>
              </div>
            </div>
          </div>

          {/* Edit Button */}
          <div className="shrink-0">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
            >
              <Edit3 className="w-3.5 h-3.5 text-purple-600" />
              <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Edit Form Modal/Drawer if editing */}
      {isEditing && (
        <form onSubmit={handleSave} className="bg-slate-50 rounded-3xl p-4 sm:p-5 border border-purple-200 shadow-xs space-y-3.5 text-xs animate-in slide-in-from-top-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <h3 className="font-black text-sm text-purple-900 uppercase font-gaming">
              EDIT PLAYER CREDENTIALS
            </h3>
            <span className="text-[11px] text-slate-500">Update in-game details</span>
          </div>

          {/* Avatar selector */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">Avatar:</label>
            <div className="flex items-center gap-2">
              {AVATAR_OPTIONS.map((av, i) => (
                <button
                  type="button"
                  key={i}
                  onClick={() => setAvatar(av)}
                  className={`w-10 h-10 rounded-xl overflow-hidden border-2 transition-all ${
                    avatar === av ? 'border-purple-600 scale-105 shadow-md' : 'border-slate-200 opacity-60'
                  }`}
                >
                  <img src={av} alt="Avatar" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 focus:border-purple-600 outline-hidden"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">In-Game Name (IGN):</label>
              <input
                type="text"
                value={inGameName}
                onChange={(e) => setInGameName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 focus:border-purple-600 outline-hidden font-gaming"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Free Fire UID:</label>
              <input
                type="text"
                value={ffUid}
                onChange={(e) => setFfUid(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 focus:border-purple-600 outline-hidden font-mono"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Phone Number:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 focus:border-purple-600 outline-hidden font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold flex items-center gap-1.5 shadow-md"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Career Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs text-center">
          <Gamepad2 className="w-5 h-5 text-purple-600 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Matches</span>
          <span className="text-xl font-black text-slate-900 font-gaming">{currentUser.totalMatches}</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs text-center">
          <Trophy className="w-5 h-5 text-amber-500 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Wins</span>
          <span className="text-xl font-black text-amber-600 font-gaming">{currentUser.totalWins}</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs text-center">
          <TrendingUp className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Win Rate</span>
          <span className="text-xl font-black text-emerald-600 font-gaming">{currentUser.winRate}%</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs text-center">
          <Flame className="w-5 h-5 text-rose-500 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Earnings</span>
          <span className="text-xl font-black text-purple-700 font-gaming">৳{currentUser.totalEarnings}</span>
        </div>
      </div>

      {/* Account Settings / Actions */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-4 space-y-2 text-xs">
        <h4 className="font-extrabold text-slate-900 uppercase font-gaming tracking-wide mb-2">
          Account & Security
        </h4>

        <div className="divide-y divide-slate-100">
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-600">Registered Email</span>
            <span className="font-medium text-slate-900 font-mono">{currentUser.email}</span>
          </div>
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-600">Account Status</span>
            <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full text-[10px]">
              {currentUser.status}
            </span>
          </div>
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-600">Access Admin Dashboard</span>
            <button
              onClick={() => setViewMode('admin')}
              className="text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Open Admin
            </button>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100">
          <button
            onClick={logout}
            className="w-full py-2.5 px-4 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out of Account
          </button>
        </div>
      </div>
    </div>
  );
};
