import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BannerSlider } from './BannerSlider';
import { AnnouncementBar } from './AnnouncementBar';
import { GameModeGrid } from './GameModeGrid';
import { TournamentItem } from './TournamentCard';
import { Search, Filter, Sparkles, Swords, RefreshCw } from 'lucide-react';
import { MatchType } from '../../types';

export const PlayView: React.FC = () => {
  const { 
    tournaments, 
    selectedCategory, 
    setSelectedCategory, 
    refreshAll, 
    isLoading,
    t 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [matchTypeFilter, setMatchTypeFilter] = useState<MatchType | 'ALL'>('ALL');

  // Filter tournaments
  const filteredTournaments = tournaments.filter((trn) => {
    // Category filter
    if (selectedCategory !== 'ALL' && trn.gameMode !== selectedCategory) {
      return false;
    }

    // Match type (Solo / Duo / Squad) filter
    if (matchTypeFilter !== 'ALL' && trn.matchType !== matchTypeFilter) {
      return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        trn.title.toLowerCase().includes(q) ||
        trn.gameMode.toLowerCase().includes(q) ||
        trn.map.toLowerCase().includes(q)
      );
    }

    return true;
  });

  return (
    <div className="pb-24 space-y-4">
      {/* Top Banner Slider matching reference image */}
      <BannerSlider />

      {/* Orange Announcement Bar matching reference image */}
      <AnnouncementBar />

      {/* Game Mode 2-Column Grid matching reference image */}
      <GameModeGrid />

      {/* Tournament Matches Section */}
      <div className="px-3 pt-2 space-y-3">
        {/* Section Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-4 bg-purple-600 rounded-full"></div>
            <h2 className="text-base sm:text-lg font-black tracking-wider text-slate-800 uppercase font-gaming">
              {selectedCategory === 'ALL' ? 'ACTIVE TOURNAMENTS' : selectedCategory}
            </h2>
            <span className="text-xs bg-purple-100 text-purple-700 font-bold px-2 py-0.5 rounded-full">
              {filteredTournaments.length}
            </span>
          </div>

          <button
            onClick={() => refreshAll()}
            disabled={isLoading}
            className="p-1.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            title="Refresh Tournaments"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-purple-600' : ''}`} />
          </button>
        </div>

        {/* Filters & Search Row */}
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tournament name, map (Bermuda...)"
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:border-purple-600 shadow-2xs"
            />
          </div>

          {/* Match Type Pills: All, Solo, Duo, Squad */}
          <div className="flex gap-1 overflow-x-auto no-scrollbar shrink-0">
            {(['ALL', 'Solo', 'Duo', 'Squad'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setMatchTypeFilter(type)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  matchTypeFilter === type
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Tournament List Cards */}
        {filteredTournaments.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 shadow-xs space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto">
              <Swords className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-sm text-slate-800">No tournaments found</h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              No tournaments match your current filters. Try changing category or reset filters.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('ALL');
                setMatchTypeFilter('ALL');
                setSearchQuery('');
              }}
              className="px-4 py-2 rounded-xl bg-purple-700 text-white font-bold text-xs"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredTournaments.map((trn) => (
              <TournamentItem key={trn.id} tournament={trn} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
