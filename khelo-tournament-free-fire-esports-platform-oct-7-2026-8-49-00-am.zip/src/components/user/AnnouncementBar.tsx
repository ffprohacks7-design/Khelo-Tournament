import React from 'react';
import { useApp } from '../../context/AppContext';
import { Megaphone, ShoppingCart, ChevronRight } from 'lucide-react';

export const AnnouncementBar: React.FC = () => {
  const { settings, language, setIsShopModalOpen } = useApp();

  const noticeText = language === 'bn' 
    ? (settings?.marqueeNoticeBn || 'কম দামে ডায়মন্ড টপ আপ করতে নিচে Shop বাটনে ক্লিক করুন।')
    : (settings?.marqueeNoticeEn || 'Top up Free Fire Diamonds at the cheapest rate by clicking Shop below!');

  return (
    <div className="px-3 pt-2">
      <div 
        onClick={() => setIsShopModalOpen(true)}
        className="cursor-pointer group flex items-center justify-between gap-2 bg-gradient-to-r from-orange-500/10 via-amber-500/15 to-orange-500/10 border border-orange-400/30 rounded-xl px-3 py-2 text-orange-800 hover:bg-orange-500/20 transition-all shadow-xs"
      >
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="w-6 h-6 rounded-lg bg-orange-500 text-white flex items-center justify-center shrink-0 shadow-xs animate-bounce">
            <Megaphone className="w-3.5 h-3.5" />
          </div>
          <p className="text-xs sm:text-sm font-bold font-bengali text-orange-600 truncate group-hover:text-orange-700">
            {noticeText}
          </p>
        </div>

        <div className="flex items-center gap-1 shrink-0 text-orange-700 font-bold text-xs bg-orange-100 group-hover:bg-orange-200 px-2 py-0.5 rounded-full transition-colors">
          <ShoppingCart className="w-3 h-3" />
          <span className="hidden xs:inline">Shop</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </div>
  );
};
