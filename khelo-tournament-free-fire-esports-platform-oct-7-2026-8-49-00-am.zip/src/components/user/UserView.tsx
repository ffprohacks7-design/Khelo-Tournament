import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserNavbar } from './UserNavbar';
import { PlayView } from './PlayView';
import { MyMatchesView } from './MyMatchesView';
import { ResultsView } from './ResultsView';
import { ProfileView } from './ProfileView';
import { WalletView } from './WalletView';
import { BottomNav } from './BottomNav';
import { TournamentDetailModal } from './TournamentDetailModal';
import { JoinTournamentModal } from './JoinTournamentModal';
import { ShopModal } from './ShopModal';
import { SupportModal } from './SupportModal';
import { AuthModal } from '../common/AuthModal';
import { NotificationDrawer } from '../common/NotificationDrawer';
import { Wifi, Signal, Battery, Smartphone, Monitor } from 'lucide-react';

export const UserView: React.FC = () => {
  const { 
    activeTab, 
    devicePreviewMode, 
    setDevicePreviewMode,
    isWalletModalOpen,
    setIsWalletModalOpen 
  } = useApp();

  // Content according to active tab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'play':
        return <PlayView />;
      case 'matches':
        return <div className="pb-24"><MyMatchesView /></div>;
      case 'results':
        return <div className="pb-24"><ResultsView /></div>;
      case 'profile':
        return <div className="pb-24"><ProfileView /></div>;
      default:
        return <PlayView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-900 flex flex-col items-center">
      {/* If Mobile Preview Mode: Show Realistic Android Phone Frame like the reference screenshot! */}
      {devicePreviewMode === 'mobile' ? (
        <div className="w-full flex flex-col items-center py-2 sm:py-6 px-1">
          {/* Subtle device header controls */}
          <div className="hidden sm:flex items-center justify-between w-full max-w-[430px] mb-2 px-2 text-xs text-slate-500 font-medium">
            <span className="flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-purple-600" />
              Android Mobile View
            </span>
            <button
              onClick={() => setDevicePreviewMode('fullscreen')}
              className="hover:text-purple-700 flex items-center gap-1 font-semibold"
            >
              <Monitor className="w-3.5 h-3.5" />
              Switch to Wide Desktop View
            </button>
          </div>

          {/* Android Smartphone Mockup Chassis */}
          <div className="w-full max-w-[430px] bg-slate-950 sm:rounded-[44px] sm:p-3 sm:shadow-2xl sm:ring-8 sm:ring-slate-800/80 overflow-hidden relative">
            
            {/* Screen Content Wrapper */}
            <div className="w-full bg-slate-50 sm:rounded-[36px] overflow-hidden min-h-[92vh] sm:min-h-[840px] flex flex-col relative border border-slate-200">
              
              {/* Android Status Bar matching reference screenshot (8:26, VoLTE, 4G, 95% battery) */}
              <div className="bg-white/95 px-5 pt-2 pb-1 flex items-center justify-between text-[11px] font-bold text-slate-700 shrink-0 select-none">
                <span className="font-gaming tracking-wide">8:26</span>

                {/* Center camera pill cutout */}
                <div className="w-16 h-4 bg-slate-950 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-slate-900 border border-slate-800"></div>
                </div>

                <div className="flex items-center gap-1.5 text-slate-600">
                  <span className="text-[10px] font-mono">VoLTE</span>
                  <Signal className="w-3 h-3" />
                  <Wifi className="w-3 h-3" />
                  <div className="flex items-center gap-0.5">
                    <span className="text-[10px] font-mono">95%</span>
                    <Battery className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              {/* Top Navigation */}
              <UserNavbar />

              {/* Main Body */}
              <main className="flex-1 overflow-y-auto">
                {renderTabContent()}
              </main>

              {/* Bottom Navigation */}
              <BottomNav />

              {/* Android Home indicator bar at bottom */}
              <div className="w-full flex justify-center py-1 bg-white select-none shrink-0 pointer-events-none">
                <div className="w-32 h-1 bg-slate-400 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Fullscreen Responsive Mode for tablets/desktops */
        <div className="w-full min-h-screen flex flex-col bg-slate-50">
          <UserNavbar />
          <main className="flex-1 max-w-4xl w-full mx-auto pb-24 px-2">
            {renderTabContent()}
          </main>
          <BottomNav />
        </div>
      )}

      {/* Global Modals */}
      <TournamentDetailModal />
      <JoinTournamentModal />
      <ShopModal />
      <SupportModal />
      <AuthModal />
      <NotificationDrawer />

      {/* Direct Wallet Modal if triggered from navbar */}
      {isWalletModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 max-h-[92vh] flex flex-col">
            <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <span className="font-extrabold text-xs uppercase font-gaming text-amber-300">
                TOURNAMENT REWARD WALLET
              </span>
              <button
                onClick={() => setIsWalletModalOpen(false)}
                className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <WalletView />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
