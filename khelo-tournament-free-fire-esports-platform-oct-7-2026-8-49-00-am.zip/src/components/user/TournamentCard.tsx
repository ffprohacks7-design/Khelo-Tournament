import React from 'react';
import { Tournament } from '../../types';
import { useApp } from '../../context/AppContext';
import { Trophy, Users, Calendar, Clock, Crosshair, CheckCircle2, Lock, Key } from 'lucide-react';

interface Props {
  tournament: Tournament;
}

export const TournamentCard: React.FC = () => {
  return null;
};

export const TournamentItem: React.FC<Props> = ({ tournament }) => {
  const { 
    currentUser, 
    setSelectedTournament, 
    setIsDetailOpen, 
    setIsJoinModalOpen,
    t 
  } = useApp();

  const isFull = tournament.joinedSlots >= tournament.maxSlots;
  const isJoined = currentUser ? false : false; // Will check participant array or state

  // Status badge colors
  let statusBadge = (
    <span className="bg-emerald-500/15 text-emerald-700 border border-emerald-500/30 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
      {tournament.status}
    </span>
  );

  if (tournament.status === 'Live') {
    statusBadge = (
      <span className="bg-rose-500 text-white font-bold text-[10px] px-2 py-0.5 rounded-full uppercase flex items-center gap-1 animate-pulse">
        <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
        LIVE NOW
      </span>
    );
  } else if (tournament.status === 'Full') {
    statusBadge = (
      <span className="bg-amber-500/20 text-amber-800 border border-amber-500/30 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
        FULL
      </span>
    );
  } else if (tournament.status === 'Completed') {
    statusBadge = (
      <span className="bg-slate-200 text-slate-700 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
        COMPLETED
      </span>
    );
  }

  const slotPercent = Math.min(100, Math.round((tournament.joinedSlots / tournament.maxSlots) * 100));

  const handleOpenDetail = () => {
    setSelectedTournament(tournament);
    setIsDetailOpen(true);
  };

  const handleQuickJoin = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedTournament(tournament);
    setIsJoinModalOpen(true);
  };

  return (
    <div 
      onClick={handleOpenDetail}
      className="cursor-pointer group relative bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-md hover:border-purple-300 transition-all duration-200 overflow-hidden"
    >
      {/* Top Banner Image with Overlay Tags */}
      <div className="relative h-32 sm:h-36 w-full overflow-hidden bg-slate-900">
        <img
          src={tournament.bannerImage}
          alt={tournament.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-linear-to-t from-slate-950/90 via-slate-950/30 to-black/40" />

        {/* Badges on Top Left & Right */}
        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10">
          <span className="bg-purple-900/90 backdrop-blur-md text-purple-200 text-[10px] font-black px-2 py-0.5 rounded-md border border-purple-400/30 font-gaming uppercase tracking-wider">
            {tournament.gameMode}
          </span>
          <span className="bg-slate-900/80 backdrop-blur-md text-slate-200 text-[10px] font-bold px-2 py-0.5 rounded-md">
            {tournament.matchType}
          </span>
          <span className="bg-slate-900/80 backdrop-blur-md text-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded-md">
            {tournament.map}
          </span>
        </div>

        <div className="absolute top-2.5 right-2.5 z-10">
          {statusBadge}
        </div>

        {/* Room Published Indicator on image if active */}
        {tournament.isRoomPublished && (
          <div className="absolute bottom-2.5 right-2.5 z-10 bg-emerald-600/90 backdrop-blur-md text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-md">
            <Key className="w-3 h-3 text-yellow-300" />
            ROOM ID READY
          </div>
        )}

        {/* Bottom Banner Title */}
        <div className="absolute bottom-2.5 left-2.5 z-10 pr-24">
          <h3 className="text-white font-extrabold text-sm sm:text-base font-gaming tracking-wide drop-shadow-md truncate">
            {tournament.title}
          </h3>
          <div className="flex items-center gap-2 text-slate-300 text-[11px] font-medium">
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-400" />
              {tournament.matchDate}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-yellow-300 font-semibold">
              <Clock className="w-3 h-3" />
              {tournament.matchTime}
            </span>
          </div>
        </div>
      </div>

      {/* Card Content & Metrics */}
      <div className="p-3.5 space-y-3">
        {/* Metric Badges Row */}
        <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
          <div>
            <span className="text-[10px] text-slate-500 font-medium uppercase block">
              {t.prizePool}
            </span>
            <span className="font-black text-sm sm:text-base text-purple-700 font-gaming">
              ৳{tournament.prizePool}
            </span>
          </div>
          <div className="border-x border-slate-200">
            <span className="text-[10px] text-slate-500 font-medium uppercase block">
              {t.perKill}
            </span>
            <span className="font-extrabold text-sm sm:text-base text-slate-800 font-gaming">
              {tournament.perKillPrize > 0 ? `৳${tournament.perKillPrize}` : '—'}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-medium uppercase block">
              {t.entryFee}
            </span>
            <span className={`font-black text-sm sm:text-base font-gaming ${tournament.entryFee === 0 ? 'text-emerald-600' : 'text-slate-900'}`}>
              {tournament.entryFee === 0 ? 'FREE' : `৳${tournament.entryFee}`}
            </span>
          </div>
        </div>

        {/* Slots Progress Bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-semibold text-slate-600">
            <span className="flex items-center gap-1">
              <Users className="w-3 h-3 text-purple-600" />
              <span>Joined:</span>
              <strong className="text-slate-900">{tournament.joinedSlots}/{tournament.maxSlots}</strong>
            </span>
            <span className="text-purple-600">
              {tournament.maxSlots - tournament.joinedSlots} slots left
            </span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                slotPercent >= 90
                  ? 'bg-rose-500'
                  : slotPercent >= 70
                  ? 'bg-amber-500'
                  : 'bg-linear-to-r from-purple-600 to-indigo-600'
              }`}
              style={{ width: `${slotPercent}%` }}
            />
          </div>
        </div>

        {/* Buttons Row */}
        <div className="pt-1 flex items-center gap-2">
          <button
            onClick={handleOpenDetail}
            className="flex-1 py-2 px-3 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs transition-colors text-center"
          >
            {t.viewDetails}
          </button>

          {tournament.status === 'Registration Open' && !isFull ? (
            <button
              onClick={handleQuickJoin}
              className="flex-1 py-2 px-3 rounded-xl bg-linear-to-r from-purple-600 via-indigo-600 to-purple-700 hover:opacity-95 text-white font-extrabold text-xs shadow-md shadow-purple-600/20 transition-all font-gaming tracking-wider active:scale-95 text-center"
            >
              {t.joinNow}
            </button>
          ) : tournament.status === 'Live' ? (
            <button
              onClick={handleOpenDetail}
              className="flex-1 py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs shadow-md transition-all font-gaming text-center"
            >
              WATCH / ROOM
            </button>
          ) : tournament.status === 'Completed' ? (
            <button
              onClick={handleOpenDetail}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-800 text-white font-bold text-xs hover:bg-slate-900 transition-colors text-center"
            >
              VIEW RESULTS
            </button>
          ) : (
            <button
              disabled
              className="flex-1 py-2 px-3 rounded-xl bg-slate-100 text-slate-400 font-bold text-xs cursor-not-allowed text-center"
            >
              {tournament.status === 'Full' ? t.full : t.closed}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
