import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Trophy, 
  Users, 
  Calendar, 
  Clock, 
  MapPin, 
  ShieldAlert, 
  Key, 
  Lock, 
  Copy, 
  Check, 
  AlertCircle,
  Award,
  Sparkles 
} from 'lucide-react';
import { Participant } from '../../types';
import { api } from '../../services/api';

export const TournamentDetailModal: React.FC = () => {
  const { 
    selectedTournament, 
    isDetailOpen, 
    setIsDetailOpen, 
    setIsJoinModalOpen,
    currentUser,
    showToast,
    t 
  } = useApp();

  const [copiedId, setCopiedId] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'rules' | 'prizes' | 'players'>('info');
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loadingParticipants, setLoadingParticipants] = useState(false);

  useEffect(() => {
    if (selectedTournament && isDetailOpen) {
      setLoadingParticipants(true);
      api.getParticipants(selectedTournament.id)
        .then((data) => setParticipants(data))
        .catch(() => setParticipants([]))
        .finally(() => setLoadingParticipants(false));
    }
  }, [selectedTournament, isDetailOpen]);

  if (!isDetailOpen || !selectedTournament) return null;

  const isUserJoined = participants.some((p) => p.userId === currentUser?.id);
  const isFull = selectedTournament.joinedSlots >= selectedTournament.maxSlots;

  const copyToClipboard = (text: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } else {
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
    showToast(`${type === 'id' ? 'Room ID' : 'Password'} copied!`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200">
        
        {/* Modal Header & Banner */}
        <div className="relative h-44 sm:h-48 w-full bg-slate-900 shrink-0">
          <img
            src={selectedTournament.bannerImage}
            alt={selectedTournament.title}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/50 to-transparent" />

          {/* Close button */}
          <button
            onClick={() => setIsDetailOpen(false)}
            className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Badges on Banner */}
          <div className="absolute top-3 left-3 z-10 flex flex-wrap gap-1.5">
            <span className="bg-purple-900/90 text-purple-200 text-xs font-black px-2.5 py-0.5 rounded-lg border border-purple-400/40 uppercase font-gaming">
              {selectedTournament.gameMode}
            </span>
            <span className="bg-slate-900/80 text-white text-xs font-bold px-2 py-0.5 rounded-lg">
              {selectedTournament.matchType}
            </span>
            <span className="bg-slate-900/80 text-amber-300 text-xs font-bold px-2 py-0.5 rounded-lg">
              {selectedTournament.map}
            </span>
          </div>

          {/* Title & Timing */}
          <div className="absolute bottom-3 left-3 right-3 z-10 text-white">
            <h2 className="text-lg sm:text-xl font-black font-gaming tracking-wide drop-shadow-md">
              {selectedTournament.title}
            </h2>
            <div className="flex items-center gap-3 text-xs text-slate-300 font-medium mt-1">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {selectedTournament.matchDate}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-yellow-300 font-bold">
                <Clock className="w-3.5 h-3.5" />
                {selectedTournament.matchTime}
              </span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">
                {selectedTournament.status}
              </span>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold text-slate-600 px-3 shrink-0">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'info'
                ? 'border-purple-600 text-purple-700 bg-white'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Match Info
          </button>
          <button
            onClick={() => setActiveTab('prizes')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'prizes'
                ? 'border-purple-600 text-purple-700 bg-white'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Prize Pool
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'rules'
                ? 'border-purple-600 text-purple-700 bg-white'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Rules
          </button>
          <button
            onClick={() => setActiveTab('players')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'players'
                ? 'border-purple-600 text-purple-700 bg-white'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Players ({selectedTournament.joinedSlots})
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* ROOM CREDENTIALS CARD - Hidden until Admin publishes */}
          <div className="rounded-2xl border transition-all overflow-hidden">
            {selectedTournament.isRoomPublished ? (
              <div className="bg-linear-to-r from-emerald-950 via-slate-900 to-emerald-950 border-emerald-500/50 p-4 text-white">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-emerald-500/30">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500 text-white flex items-center justify-center shadow-md">
                      <Key className="w-4 h-4 text-yellow-300" />
                    </div>
                    <div>
                      <h4 className="font-black text-sm font-gaming text-emerald-300 tracking-wide">
                        CUSTOM ROOM CREDENTIALS
                      </h4>
                      <p className="text-[11px] text-emerald-200">
                        {t.roomReadyNotice}
                      </p>
                    </div>
                  </div>
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-400/40 uppercase">
                    PUBLISHED
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Room ID Box */}
                  <div className="bg-black/50 p-2.5 rounded-xl border border-emerald-500/30">
                    <span className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                      {t.roomId}
                    </span>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-black text-base sm:text-lg text-white tracking-widest">
                        {selectedTournament.roomId || 'PENDING'}
                      </span>
                      {selectedTournament.roomId && (
                        <button
                          onClick={() => copyToClipboard(selectedTournament.roomId!, 'id')}
                          className="p-1.5 hover:bg-white/10 rounded-lg text-emerald-400 transition-colors"
                          title="Copy Room ID"
                        >
                          {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Room Password Box */}
                  <div className="bg-black/50 p-2.5 rounded-xl border border-emerald-500/30">
                    <span className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                      {t.roomPassword}
                    </span>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-black text-base sm:text-lg text-yellow-300 tracking-widest">
                        {selectedTournament.roomPassword || 'PENDING'}
                      </span>
                      {selectedTournament.roomPassword && (
                        <button
                          onClick={() => copyToClipboard(selectedTournament.roomPassword!, 'pass')}
                          className="p-1.5 hover:bg-white/10 rounded-lg text-yellow-400 transition-colors"
                          title="Copy Password"
                        >
                          {copiedPass ? <Check className="w-4 h-4 text-yellow-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-900 border-slate-700 p-3.5 text-white flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 text-slate-400">
                  <Lock className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">
                    Room ID & Password Locked
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    {t.roomHiddenNotice}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* TAB 1: Match Info */}
          {activeTab === 'info' && (
            <div className="space-y-3.5">
              {/* Prize & Entry Summary Cards */}
              <div className="grid grid-cols-3 gap-2.5">
                <div className="bg-purple-50 border border-purple-200/80 p-3 rounded-2xl text-center">
                  <span className="text-[10px] font-bold text-purple-600 uppercase block">
                    {t.prizePool}
                  </span>
                  <span className="text-base sm:text-lg font-black text-purple-900 font-gaming">
                    ৳{selectedTournament.prizePool}
                  </span>
                </div>
                <div className="bg-slate-50 border border-slate-200/80 p-3 rounded-2xl text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    {t.entryFee}
                  </span>
                  <span className="text-base sm:text-lg font-black text-slate-900 font-gaming">
                    {selectedTournament.entryFee === 0 ? 'FREE' : `৳${selectedTournament.entryFee}`}
                  </span>
                </div>
                <div className="bg-emerald-50 border border-emerald-200/80 p-3 rounded-2xl text-center">
                  <span className="text-[10px] font-bold text-emerald-600 uppercase block">
                    {t.perKill}
                  </span>
                  <span className="text-base sm:text-lg font-black text-emerald-800 font-gaming">
                    {selectedTournament.perKillPrize > 0 ? `৳${selectedTournament.perKillPrize}` : 'None'}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700 leading-relaxed">
                <h4 className="font-bold text-slate-900 mb-1">About Match:</h4>
                <p>{selectedTournament.description}</p>
              </div>

              {/* Match Details Matrix */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Map</span>
                  <span className="font-bold text-slate-800">{selectedTournament.map}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Game Mode</span>
                  <span className="font-bold text-slate-800">{selectedTournament.gameMode} ({selectedTournament.matchType})</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Slots Available</span>
                  <span className="font-bold text-purple-700">{selectedTournament.maxSlots - selectedTournament.joinedSlots} / {selectedTournament.maxSlots}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Tournament ID</span>
                  <span className="font-mono text-slate-600">{selectedTournament.id}</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Prize Pool */}
          {activeTab === 'prizes' && (
            <div className="space-y-3">
              <div className="bg-linear-to-r from-amber-500/10 via-yellow-500/10 to-amber-500/10 p-3.5 rounded-2xl border border-amber-300/40 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-800 uppercase tracking-wider block">
                    TOTAL CASH PRIZE
                  </span>
                  <span className="text-2xl font-black text-amber-950 font-gaming">
                    ৳{selectedTournament.prizePool}
                  </span>
                </div>
                <Trophy className="w-10 h-10 text-amber-500" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-950">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-900 font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <span className="font-bold text-xs">1st Place (Winner)</span>
                  </div>
                  <span className="font-black text-sm font-gaming">৳{selectedTournament.prizeDistribution.rank1}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100 border border-slate-200 text-slate-900">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-slate-300 text-slate-900 font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <span className="font-bold text-xs">2nd Place (Runner-up)</span>
                  </div>
                  <span className="font-black text-sm font-gaming">৳{selectedTournament.prizeDistribution.rank2}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-orange-50 border border-orange-200 text-orange-950">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-orange-300 text-slate-900 font-black text-xs flex items-center justify-center">
                      3
                    </span>
                    <span className="font-bold text-xs">3rd Place</span>
                  </div>
                  <span className="font-black text-sm font-gaming">৳{selectedTournament.prizeDistribution.rank3}</span>
                </div>

                {selectedTournament.perKillPrize > 0 && (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span className="font-bold text-xs">Each Kill Reward</span>
                    </div>
                    <span className="font-black text-sm font-gaming">৳{selectedTournament.perKillPrize} / Kill</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Rules */}
          {activeTab === 'rules' && (
            <div className="space-y-3">
              <div className="flex items-start gap-2 bg-rose-50 border border-rose-200 p-3 rounded-xl text-rose-900 text-xs">
                <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold">Strict Anti-Cheat Policy</h4>
                  <p className="mt-0.5 text-rose-800">
                    Any use of hacks, headshot scripts, or teaming up in solo will result in immediate disqualification and permanent ban.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 whitespace-pre-line leading-relaxed font-mono">
                {selectedTournament.rules}
              </div>
            </div>
          )}

          {/* TAB 4: Joined Players */}
          {activeTab === 'players' && (
            <div className="space-y-2">
              {loadingParticipants ? (
                <div className="py-8 text-center text-xs text-slate-500 animate-pulse">
                  Loading participants...
                </div>
              ) : participants.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No players have joined this tournament yet. Be the first to join!
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {participants.map((player, idx) => (
                    <div key={player.id} className="py-2 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-400 w-5 text-center">#{idx + 1}</span>
                        <div>
                          <p className="font-bold text-slate-900 font-gaming">{player.playerName}</p>
                          <p className="text-[10px] text-slate-500">UID: {player.ffUid}</p>
                        </div>
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full text-[10px]">
                        {player.paymentStatus}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Bottom Actions */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center gap-2.5 shrink-0">
          {isUserJoined ? (
            <div className="w-full flex items-center justify-between bg-emerald-100 border border-emerald-300 text-emerald-900 p-2.5 rounded-xl text-xs font-bold">
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                You are registered for this match!
              </span>
              <span className="text-[11px] text-emerald-800 font-mono">Slot Confirmed</span>
            </div>
          ) : selectedTournament.status === 'Registration Open' && !isFull ? (
            <>
              <button
                onClick={() => {
                  setIsDetailOpen(false);
                  setIsJoinModalOpen(true);
                }}
                className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-purple-600 via-indigo-600 to-purple-700 hover:opacity-95 text-white font-extrabold text-sm shadow-lg shadow-purple-600/30 transition-all font-gaming tracking-wide active:scale-95 text-center"
              >
                JOIN TOURNAMENT ({selectedTournament.entryFee === 0 ? 'FREE' : `৳${selectedTournament.entryFee}`})
              </button>
            </>
          ) : (
            <button
              disabled
              className="w-full py-3 px-4 rounded-xl bg-slate-200 text-slate-400 font-bold text-xs cursor-not-allowed text-center uppercase"
            >
              {selectedTournament.status === 'Completed' ? 'Tournament Completed' : 'Registration Closed'}
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
