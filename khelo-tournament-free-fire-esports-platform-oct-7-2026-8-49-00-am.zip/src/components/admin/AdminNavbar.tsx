import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, ArrowLeft, LogOut, ExternalLink, RefreshCw } from 'lucide-react';

interface Props {
  activeAdminTab: string;
  setActiveAdminTab: (tab: string) => void;
}

export const AdminNavbar: React.FC<Props> = ({ activeAdminTab, setActiveAdminTab }) => {
  const { setViewMode, currentUser, refreshAll, isLoading } = useApp();

  const TABS = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'tournaments', label: 'Tournaments' },
    { id: 'players', label: 'Players' },
    { id: 'rewards', label: 'Rewards & Wallet' },
    { id: 'banners', label: 'Banners' },
    { id: 'notifications', label: 'Broadcasts' },
    { id: 'settings', label: 'Settings' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top micro bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
          <span className="font-extrabold text-amber-300 font-gaming tracking-wider uppercase">
            KHelo Tournament Master Control
          </span>
          <span className="hidden sm:inline bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-bold px-2 py-0.5 rounded-sm">
            ADMINISTRATOR
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => refreshAll()}
            disabled={isLoading}
            className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-purple-400' : ''}`} />
          </button>

          {/* Switch back to User App button */}
          <button
            onClick={() => setViewMode('user')}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Switch to User App</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="px-4 py-1 flex items-center gap-1 overflow-x-auto no-scrollbar">
        {TABS.map((tab) => {
          const isActive = activeAdminTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id)}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-all shrink-0 font-gaming uppercase tracking-wider ${
                isActive
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
