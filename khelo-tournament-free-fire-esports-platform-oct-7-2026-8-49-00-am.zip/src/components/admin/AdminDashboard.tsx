import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  Swords, 
  Trophy, 
  Wallet, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Key, 
  Send, 
  Flame,
  ArrowUpRight 
} from 'lucide-react';

interface Props {
  setActiveAdminTab: (tab: string) => void;
  openCreateModal: () => void;
}

export const AdminDashboard: React.FC<Props> = ({ setActiveAdminTab, openCreateModal }) => {
  const { tournaments, users, transactions, results, banners } = useApp();

  // Metrics calculation
  const totalUsers = users.length;
  const activeUsers = users.filter((u) => u.status === 'Active').length;
  const totalTournaments = tournaments.length;
  const liveTournaments = tournaments.filter((t) => t.status === 'Live').length;
  const completedTournaments = tournaments.filter((t) => t.status === 'Completed').length;
  const totalParticipants = tournaments.reduce((acc, t) => acc + t.joinedSlots, 0);
  
  const totalRewardsDistributed = transactions
    .filter((tx) => (tx.type === 'Match Reward' || tx.type === 'Admin Bonus') && tx.status === 'Approved')
    .reduce((acc, tx) => acc + Math.abs(tx.amount), 0);

  const pendingRequests = transactions.filter((tx) => tx.status === 'Pending');

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Welcome Banner */}
      <div className="bg-linear-to-r from-purple-950 via-slate-900 to-indigo-950 rounded-3xl p-5 sm:p-6 text-white border border-purple-500/30 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-widest font-gaming">
            SYSTEM OVERVIEW & TOURNAMENT OPERATIONS
          </span>
          <h1 className="text-xl sm:text-2xl font-black font-gaming tracking-wide text-white mt-1">
            Free Fire Esports Control Center
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-lg">
            Manage registrations, custom room credentials, instant bracket results, and player rewards in real-time.
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={openCreateModal}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md transition-all font-gaming"
          >
            <Plus className="w-4 h-4" />
            <span>Create Tournament</span>
          </button>
          <button
            onClick={() => setActiveAdminTab('rewards')}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors"
          >
            <Wallet className="w-4 h-4 text-amber-400" />
            <span>Pending ({pendingRequests.length})</span>
          </button>
        </div>
      </div>

      {/* 8 Stats Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Total Users */}
        <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Users</span>
            <Users className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-gaming">
            {totalUsers}
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold mt-1 block">
            {activeUsers} Active Players
          </span>
        </div>

        {/* Card 2: Total Tournaments */}
        <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Tournaments</span>
            <Swords className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-gaming">
            {totalTournaments}
          </div>
          <span className="text-[11px] text-slate-400 font-semibold mt-1 block">
            {liveTournaments} Live • {completedTournaments} Done
          </span>
        </div>

        {/* Card 3: Total Participants */}
        <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Participants</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-gaming">
            {totalParticipants}
          </div>
          <span className="text-[11px] text-purple-300 font-semibold mt-1 block">
            Across all brackets
          </span>
        </div>

        {/* Card 4: Rewards Distributed */}
        <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Rewards</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400 font-gaming">
            ৳{totalRewardsDistributed}
          </div>
          <span className="text-[11px] text-slate-400 font-semibold mt-1 block">
            Winner payouts
          </span>
        </div>
      </div>

      {/* Second Row: Pending Actions & Live Tournaments */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Pending Requests Column (2 cols wide on desktop) */}
        <div className="lg:col-span-2 bg-slate-900 rounded-3xl p-5 border border-slate-800 shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></div>
              <h3 className="font-extrabold text-sm sm:text-base text-white uppercase font-gaming tracking-wide">
                Pending Reward & Transaction Requests
              </h3>
            </div>
            <button
              onClick={() => setActiveAdminTab('rewards')}
              className="text-xs text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
            >
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {pendingRequests.length === 0 ? (
            <div className="py-10 text-center text-slate-500 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-60" />
              All deposit and withdrawal requests are cleared.
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {pendingRequests.slice(0, 4).map((req) => (
                <div key={req.id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-bold text-white font-gaming">
                      {req.userName} • {req.type}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {req.description} ({req.date} {req.time})
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-black text-sm text-amber-400">
                      ৳{Math.abs(req.amount)}
                    </span>
                    <button
                      onClick={() => setActiveAdminTab('rewards')}
                      className="px-2.5 py-1 rounded-lg bg-purple-700 hover:bg-purple-600 text-white font-bold text-[11px]"
                    >
                      Review
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Live / Upcoming Tournament Monitor */}
        <div className="bg-slate-900 rounded-3xl p-5 border border-slate-800 shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-white uppercase font-gaming tracking-wide">
              Active Match Monitor
            </h3>
            <span className="bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
              {liveTournaments} LIVE
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            {tournaments.slice(0, 4).map((t) => (
              <div
                key={t.id}
                onClick={() => setActiveAdminTab('tournaments')}
                className="cursor-pointer p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-white font-gaming truncate max-w-[150px]">
                    {t.title}
                  </span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                    t.status === 'Live' ? 'bg-rose-500 text-white' :
                    t.status === 'Registration Open' ? 'bg-emerald-500/20 text-emerald-300' :
                    'bg-slate-700 text-slate-300'
                  }`}>
                    {t.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{t.gameMode} • {t.matchTime}</span>
                  <span className="font-mono text-purple-300">{t.joinedSlots}/{t.maxSlots} slots</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
