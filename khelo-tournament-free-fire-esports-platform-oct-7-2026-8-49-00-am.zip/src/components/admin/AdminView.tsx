import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminNavbar } from './AdminNavbar';
import { AdminDashboard } from './AdminDashboard';
import { AdminTournaments } from './AdminTournaments';
import { AdminPlayers } from './AdminPlayers';
import { AdminRewards } from './AdminRewards';
import { AdminBanners } from './AdminBanners';
import { AdminNotifications } from './AdminNotifications';
import { AdminSettings } from './AdminSettings';

export const AdminView: React.FC = () => {
  const [activeAdminTab, setActiveAdminTab] = useState<string>('dashboard');
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const openCreateModal = () => {
    setActiveAdminTab('tournaments');
    setIsCreateOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <AdminNavbar activeAdminTab={activeAdminTab} setActiveAdminTab={setActiveAdminTab} />

      <main className="flex-1 pb-16">
        {activeAdminTab === 'dashboard' && (
          <AdminDashboard
            setActiveAdminTab={setActiveAdminTab}
            openCreateModal={openCreateModal}
          />
        )}
        {activeAdminTab === 'tournaments' && (
          <AdminTournaments
            isCreateOpen={isCreateOpen}
            setIsCreateOpen={setIsCreateOpen}
          />
        )}
        {activeAdminTab === 'players' && <AdminPlayers />}
        {activeAdminTab === 'rewards' && <AdminRewards />}
        {activeAdminTab === 'banners' && <AdminBanners />}
        {activeAdminTab === 'notifications' && <AdminNotifications />}
        {activeAdminTab === 'settings' && <AdminSettings />}
      </main>
    </div>
  );
};
