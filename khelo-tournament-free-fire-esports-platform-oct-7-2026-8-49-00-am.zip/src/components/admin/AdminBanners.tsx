import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Banner } from '../../types';
import { api } from '../../services/api';
import { Plus, Edit2, Trash2, Eye, EyeOff, Send, Image, ExternalLink, X, Check } from 'lucide-react';

export const AdminBanners: React.FC = () => {
  const { banners, refreshAll, showToast } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [actionUrl, setActionUrl] = useState('');
  const [actionType, setActionType] = useState<'telegram' | 'tournament' | 'shop' | 'external'>('telegram');
  const [isActive, setIsActive] = useState(true);

  const handleOpenCreate = () => {
    setEditingBanner(null);
    setTitle('');
    setSubtitle('');
    setImageUrl('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1000&q=80');
    setActionUrl('https://t.me/khelobangladesh_live');
    setActionType('telegram');
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (b: Banner) => {
    setEditingBanner(b);
    setTitle(b.title);
    setSubtitle(b.subtitle || '');
    setImageUrl(b.imageUrl);
    setActionUrl(b.actionUrl || '');
    setActionType(b.actionType);
    setIsActive(b.isActive);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Banner title required', 'error');
      return;
    }

    try {
      const payload: Partial<Banner> = {
        title: title.trim(),
        subtitle: subtitle.trim(),
        imageUrl: imageUrl.trim(),
        actionUrl: actionUrl.trim(),
        actionType,
        isActive,
      };

      if (editingBanner) {
        await api.updateBanner(editingBanner.id, payload);
        showToast('Banner updated!', 'success');
      } else {
        await api.createBanner(payload);
        showToast('New promotional banner created!', 'success');
      }

      setIsModalOpen(false);
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Operation failed', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this banner?')) return;
    try {
      await api.deleteBanner(id);
      showToast('Banner deleted', 'info');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Delete failed', 'error');
    }
  };

  const handleToggle = async (b: Banner) => {
    try {
      await api.updateBanner(b.id, { isActive: !b.isActive });
      showToast(`Banner ${!b.isActive ? 'enabled' : 'disabled'}`, 'success');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Update failed', 'error');
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
            PROMOTIONAL BANNER MANAGEMENT
          </h2>
          <p className="text-xs text-slate-400">
            Control the top slider carousel, Telegram channel banner, and special announcements.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md font-gaming uppercase tracking-wider transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Banner</span>
        </button>
      </div>

      {/* Banners Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {banners.map((banner) => (
          <div
            key={banner.id}
            className="bg-slate-900 rounded-2xl border border-slate-800 shadow-lg overflow-hidden flex flex-col justify-between"
          >
            {/* Banner preview */}
            <div className="relative h-36 w-full bg-slate-950 overflow-hidden">
              <img
                src={banner.imageUrl}
                alt={banner.title}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/30 to-transparent" />

              <div className="absolute top-2.5 left-2.5">
                <span className="bg-purple-900/90 text-purple-200 text-[10px] font-black px-2 py-0.5 rounded-md font-gaming uppercase">
                  {banner.actionType}
                </span>
              </div>

              <div className="absolute top-2.5 right-2.5">
                <button
                  onClick={() => handleToggle(banner)}
                  className={`p-1 rounded-md text-[10px] font-bold flex items-center gap-1 ${
                    banner.isActive ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {banner.isActive ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  <span>{banner.isActive ? 'Active' : 'Hidden'}</span>
                </button>
              </div>

              <div className="absolute bottom-2.5 left-2.5 right-2.5">
                <h3 className="font-extrabold text-sm text-white font-gaming truncate">
                  {banner.title}
                </h3>
                <p className="text-[11px] text-slate-300 truncate">
                  {banner.subtitle || 'No subtitle'}
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-400 font-mono">
                Order: #{banner.order}
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleOpenEdit(banner)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                  title="Edit Banner"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(banner.id)}
                  className="p-1.5 rounded-lg hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                  title="Delete Banner"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <h3 className="font-black text-base font-gaming tracking-wide uppercase text-amber-300">
                {editingBanner ? 'EDIT BANNER' : 'ADD NEW BANNER'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Banner Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. JOIN US ON TELEGRAM"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming text-sm font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Subtitle / Callout</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="e.g. @khelobangladesh_live"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Image URL</label>
                <input
                  type="text"
                  required
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono text-[11px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Action Type</label>
                  <select
                    value={actionType}
                    onChange={(e) => setActionType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  >
                    <option value="telegram">Telegram Community</option>
                    <option value="tournament">Tournaments View</option>
                    <option value="shop">Diamond Shop</option>
                    <option value="external">External Link</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Action Target URL</label>
                  <input
                    type="text"
                    value={actionUrl}
                    onChange={(e) => setActionUrl(e.target.value)}
                    placeholder="https://t.me/..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold font-gaming uppercase tracking-wider"
                >
                  Save Banner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
