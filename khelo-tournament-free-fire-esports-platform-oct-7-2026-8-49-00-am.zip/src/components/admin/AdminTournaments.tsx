import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Tournament, 
  GameMode, 
  MatchType, 
  TournamentStatus 
} from '../../types';
import { api } from '../../services/api';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Key, 
  Users, 
  Trophy, 
  Play, 
  CheckCircle, 
  Clock, 
  Calendar, 
  X, 
  Lock, 
  Eye, 
  EyeOff,
  Sparkles,
  Award 
} from 'lucide-react';

interface Props {
  isCreateOpen: boolean;
  setIsCreateOpen: (open: boolean) => void;
}

export const AdminTournaments: React.FC<Props> = ({ isCreateOpen, setIsCreateOpen }) => {
  const { tournaments, refreshAll, showToast } = useApp();

  const [editingTrn, setEditingTrn] = useState<Tournament | null>(null);
  const [roomModalTrn, setRoomModalTrn] = useState<Tournament | null>(null);
  const [participantsModalTrn, setParticipantsModalTrn] = useState<Tournament | null>(null);
  const [resultsModalTrn, setResultsModalTrn] = useState<Tournament | null>(null);

  // Form states for Create/Edit
  const [title, setTitle] = useState('');
  const [gameMode, setGameMode] = useState<GameMode>('BR Match');
  const [matchType, setMatchType] = useState<MatchType>('Squad');
  const [map, setMap] = useState('Bermuda');
  const [bannerImage, setBannerImage] = useState('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80');
  const [description, setDescription] = useState('');
  const [rules, setRules] = useState('1. Fair play only.\n2. No third-party headshot scripts.\n3. Take screenshot at match end.');
  const [entryFee, setEntryFee] = useState('25');
  const [prizePool, setPrizePool] = useState('1000');
  const [perKillPrize, setPerKillPrize] = useState('15');
  const [maxSlots, setMaxSlots] = useState('48');
  const [matchDate, setMatchDate] = useState('2026-10-07');
  const [matchTime, setMatchTime] = useState('08:30 PM');
  const [status, setStatus] = useState<TournamentStatus>('Registration Open');

  // Room modal state
  const [roomId, setRoomId] = useState('');
  const [roomPassword, setRoomPassword] = useState('');
  const [isRoomPublished, setIsRoomPublished] = useState(false);

  const resetForm = () => {
    setTitle('');
    setGameMode('BR Match');
    setMatchType('Squad');
    setMap('Bermuda');
    setDescription('');
    setEntryFee('25');
    setPrizePool('1000');
    setPerKillPrize('15');
    setMaxSlots('48');
    setMatchDate('2026-10-07');
    setMatchTime('08:30 PM');
    setStatus('Registration Open');
    setEditingTrn(null);
  };

  const handleOpenEdit = (trn: Tournament) => {
    setEditingTrn(trn);
    setTitle(trn.title);
    setGameMode(trn.gameMode);
    setMatchType(trn.matchType);
    setMap(trn.map);
    setBannerImage(trn.bannerImage);
    setDescription(trn.description);
    setRules(trn.rules);
    setEntryFee(trn.entryFee.toString());
    setPrizePool(trn.prizePool.toString());
    setPerKillPrize(trn.perKillPrize.toString());
    setMaxSlots(trn.maxSlots.toString());
    setMatchDate(trn.matchDate);
    setMatchTime(trn.matchTime);
    setStatus(trn.status);
    setIsCreateOpen(true);
  };

  const handleSaveTournament = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Tournament title is required', 'error');
      return;
    }

    try {
      const payload: Partial<Tournament> = {
        title: title.trim(),
        gameMode,
        matchType,
        map,
        bannerImage,
        description: description.trim() || 'Join and play to win exciting prizes.',
        rules,
        entryFee: Number(entryFee) || 0,
        prizePool: Number(prizePool) || 500,
        perKillPrize: Number(perKillPrize) || 0,
        prizeDistribution: {
          rank1: Math.round((Number(prizePool) || 500) * 0.5),
          rank2: Math.round((Number(prizePool) || 500) * 0.3),
          rank3: Math.round((Number(prizePool) || 500) * 0.2),
          perKill: Number(perKillPrize) || 0,
        },
        maxSlots: Number(maxSlots) || 48,
        matchDate,
        matchTime,
        status,
      };

      if (editingTrn) {
        await api.updateTournament(editingTrn.id, payload);
        showToast('Tournament updated successfully!', 'success');
      } else {
        await api.createTournament(payload);
        showToast('Tournament created and broadcasted to players!', 'success');
      }

      setIsCreateOpen(false);
      resetForm();
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Operation failed', 'error');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete tournament "${name}"?`)) return;
    try {
      await api.deleteTournament(id);
      showToast(`Deleted tournament ${name}`, 'info');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete', 'error');
    }
  };

  const handleQuickStatusChange = async (trn: Tournament, newStatus: TournamentStatus) => {
    try {
      await api.updateTournament(trn.id, { status: newStatus });
      showToast(`Status updated to ${newStatus}`, 'success');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  const handleOpenRoomModal = (trn: Tournament) => {
    setRoomModalTrn(trn);
    setRoomId(trn.roomId || '');
    setRoomPassword(trn.roomPassword || '');
    setIsRoomPublished(trn.isRoomPublished || false);
  };

  const handleSaveRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomModalTrn) return;

    try {
      await api.updateRoom(roomModalTrn.id, {
        roomId: roomId.trim(),
        roomPassword: roomPassword.trim(),
        isRoomPublished,
      });

      showToast(
        isRoomPublished
          ? '🔑 Room ID & Password published! All registered players can now see them.'
          : 'Room credentials saved (hidden from players).',
        'success'
      );
      setRoomModalTrn(null);
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to update room', 'error');
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
            TOURNAMENT MANAGEMENT
          </h2>
          <p className="text-xs text-slate-400">
            Create brackets, publish room IDs & passwords, manage participants, and award prizes.
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setIsCreateOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md font-gaming uppercase tracking-wider transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Tournament</span>
        </button>
      </div>

      {/* Tournaments Table / Card Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tournaments.map((trn) => (
          <div
            key={trn.id}
            className="bg-slate-900 rounded-2xl border border-slate-800 shadow-lg overflow-hidden flex flex-col justify-between"
          >
            {/* Top Banner Image with status */}
            <div className="relative h-32 w-full bg-slate-950">
              <img
                src={trn.bannerImage}
                alt={trn.title}
                className="w-full h-full object-cover opacity-75"
              />
              <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/40 to-transparent" />

              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10">
                <span className="bg-purple-900/90 text-purple-200 text-[10px] font-black px-2 py-0.5 rounded-md font-gaming uppercase">
                  {trn.gameMode}
                </span>
                <span className="bg-slate-900/80 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md">
                  {trn.matchType}
                </span>
              </div>

              {/* Status Selector */}
              <div className="absolute top-2.5 right-2.5 z-10">
                <select
                  value={trn.status}
                  onChange={(e) => handleQuickStatusChange(trn, e.target.value as TournamentStatus)}
                  className="bg-slate-900/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md border border-slate-700 outline-hidden cursor-pointer"
                >
                  <option value="Upcoming">Upcoming</option>
                  <option value="Registration Open">Registration Open</option>
                  <option value="Full">Full</option>
                  <option value="Live">Live</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div className="absolute bottom-2.5 left-2.5 right-2.5 z-10">
                <h3 className="font-extrabold text-sm text-white font-gaming truncate">
                  {trn.title}
                </h3>
                <span className="text-[11px] text-slate-300 font-medium">
                  {trn.matchDate} • {trn.matchTime} • {trn.map}
                </span>
              </div>
            </div>

            {/* Mid Details */}
            <div className="p-3.5 space-y-3 flex-1 text-xs">
              {/* Metrics */}
              <div className="grid grid-cols-3 gap-2 bg-slate-800/60 p-2 rounded-xl text-center border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">Prize</span>
                  <span className="font-black text-amber-400 font-gaming">৳{trn.prizePool}</span>
                </div>
                <div className="border-x border-slate-700">
                  <span className="text-[10px] text-slate-400 block uppercase">Entry</span>
                  <span className="font-black text-white font-gaming">৳{trn.entryFee}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">Joined</span>
                  <span className="font-black text-purple-300 font-gaming">{trn.joinedSlots}/{trn.maxSlots}</span>
                </div>
              </div>

              {/* Room ID publishing status */}
              <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
                trn.isRoomPublished
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-800/40 border-slate-700 text-slate-400'
              }`}>
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold text-[11px] block">
                      {trn.isRoomPublished ? 'Room Credentials: LIVE' : 'Room Credentials: HIDDEN'}
                    </span>
                    <span className="font-mono text-[10px]">
                      ID: {trn.roomId || 'None'} | Pass: {trn.roomPassword || 'None'}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleOpenRoomModal(trn)}
                  className="px-2 py-1 rounded-md bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-bold font-gaming"
                >
                  Manage Room
                </button>
              </div>
            </div>

            {/* Bottom Actions Row */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-1 text-xs">
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setParticipantsModalTrn(trn)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1"
                  title="View Registered Players"
                >
                  <Users className="w-3.5 h-3.5 text-blue-400" />
                  <span>Players ({trn.joinedSlots})</span>
                </button>

                <button
                  onClick={() => setResultsModalTrn(trn)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold flex items-center gap-1"
                  title="Enter Results & Distribute Prizes"
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>Results</span>
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleOpenEdit(trn)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                  title="Edit Tournament"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(trn.id, trn.title)}
                  className="p-1.5 rounded-lg hover:bg-rose-950/60 text-slate-400 hover:text-rose-400"
                  title="Delete Tournament"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CREATE / EDIT TOURNAMENT MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white max-h-[92vh] flex flex-col animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <h3 className="font-black text-base font-gaming tracking-wide uppercase text-amber-300">
                {editingTrn ? 'EDIT TOURNAMENT' : 'CREATE NEW TOURNAMENT'}
              </h3>
              <button
                onClick={() => {
                  setIsCreateOpen(false);
                  resetForm();
                }}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTournament} className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Tournament Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. BR Bermuda Championship Season 4"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Game Mode</label>
                  <select
                    value={gameMode}
                    onChange={(e) => setGameMode(e.target.value as GameMode)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  >
                    <option value="BR Match">BR Match</option>
                    <option value="BR Survival">BR Survival</option>
                    <option value="Clash Squad">Clash Squad</option>
                    <option value="CS 2 VS 2">CS 2 VS 2</option>
                    <option value="Lone Wolf">Lone Wolf</option>
                    <option value="Free Match">Free Match</option>
                    <option value="Custom Room">Custom Room</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Match Type</label>
                  <select
                    value={matchType}
                    onChange={(e) => setMatchType(e.target.value as MatchType)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  >
                    <option value="Solo">Solo</option>
                    <option value="Duo">Duo</option>
                    <option value="Squad">Squad</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Map</label>
                  <input
                    type="text"
                    value={map}
                    onChange={(e) => setMap(e.target.value)}
                    placeholder="Bermuda / Purgatory"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Entry Fee (৳)</label>
                  <input
                    type="number"
                    value={entryFee}
                    onChange={(e) => setEntryFee(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Prize Pool (৳)</label>
                  <input
                    type="number"
                    value={prizePool}
                    onChange={(e) => setPrizePool(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming text-amber-400 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Per Kill (৳)</label>
                  <input
                    type="number"
                    value={perKillPrize}
                    onChange={(e) => setPerKillPrize(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Max Slots</label>
                  <input
                    type="number"
                    value={maxSlots}
                    onChange={(e) => setMaxSlots(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Match Date</label>
                  <input
                    type="date"
                    value={matchDate}
                    onChange={(e) => setMatchDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Match Time</label>
                  <input
                    type="text"
                    value={matchTime}
                    onChange={(e) => setMatchTime(e.target.value)}
                    placeholder="08:30 PM"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Initial Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as TournamentStatus)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                  >
                    <option value="Upcoming">Upcoming</option>
                    <option value="Registration Open">Registration Open</option>
                    <option value="Full">Full</option>
                    <option value="Live">Live</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Banner Image URL</label>
                <input
                  type="text"
                  value={bannerImage}
                  onChange={(e) => setBannerImage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Description & Guidelines</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Tournament Rules</label>
                <textarea
                  rows={3}
                  value={rules}
                  onChange={(e) => setRules(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono text-[11px]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md"
                >
                  {editingTrn ? 'Update Tournament' : 'Publish Tournament'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MANAGE ROOM CREDENTIALS MODAL */}
      {roomModalTrn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base font-gaming tracking-wide uppercase text-white">
                  CUSTOM ROOM CREDENTIALS
                </h3>
              </div>
              <button
                onClick={() => setRoomModalTrn(null)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveRoom} className="p-5 space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Tournament:</span>
                <span className="font-extrabold text-sm text-white font-gaming">{roomModalTrn.title}</span>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1 uppercase">Free Fire Room ID:</label>
                <input
                  type="text"
                  required
                  value={roomId}
                  onChange={(e) => setRoomId(e.target.value)}
                  placeholder="e.g. 84729104"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono text-base font-bold text-white tracking-widest"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1 uppercase">Room Password:</label>
                <input
                  type="text"
                  required
                  value={roomPassword}
                  onChange={(e) => setRoomPassword(e.target.value)}
                  placeholder="e.g. 8899"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-mono text-base font-bold text-yellow-300 tracking-widest"
                />
              </div>

              {/* Publish Visibility Toggle */}
              <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white flex items-center gap-1.5">
                    {isRoomPublished ? <Eye className="w-4 h-4 text-emerald-400" /> : <EyeOff className="w-4 h-4 text-slate-400" />}
                    Publish to Players
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {isRoomPublished
                      ? 'Visible to registered participants in the User App.'
                      : 'Hidden from players (Locked with notice).'}
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={isRoomPublished}
                  onChange={(e) => setIsRoomPublished(e.target.checked)}
                  className="w-5 h-5 accent-purple-600 rounded-md cursor-pointer"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95"
              >
                Save & Update Room
              </button>
            </form>
          </div>
        </div>
      )}

      {/* PARTICIPANTS LIST MODAL */}
      {participantsModalTrn && (
        <ParticipantsModal
          tournament={participantsModalTrn}
          onClose={() => setParticipantsModalTrn(null)}
        />
      )}

      {/* RESULTS PUBLISHING MODAL */}
      {resultsModalTrn && (
        <ResultsPublisherModal
          tournament={resultsModalTrn}
          onClose={() => setResultsModalTrn(null)}
        />
      )}
    </div>
  );
};

// Sub-component: Participants Modal
const ParticipantsModal: React.FC<{ tournament: Tournament; onClose: () => void }> = ({ tournament, onClose }) => {
  const { showToast, refreshAll } = useApp();
  const [participants, setParticipants] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    api.getParticipants(tournament.id)
      .then((data) => setParticipants(data))
      .catch(() => setParticipants([]))
      .finally(() => setLoading(false));
  }, [tournament.id]);

  const handleRemove = async (userId: string, name: string) => {
    if (!window.confirm(`Remove ${name} from this tournament and refund entry fee?`)) return;
    try {
      await api.removeParticipant(tournament.id, userId);
      showToast(`Removed ${name}`, 'info');
      setParticipants((prev) => prev.filter((p) => p.userId !== userId));
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to remove', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white max-h-[85vh] flex flex-col">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div>
            <h3 className="font-black text-base font-gaming tracking-wide uppercase text-white">
              PARTICIPANTS ({participants.length})
            </h3>
            <p className="text-[11px] text-slate-400">{tournament.title}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-2 flex-1 text-xs">
          {loading ? (
            <div className="py-8 text-center text-slate-500">Loading participants...</div>
          ) : participants.length === 0 ? (
            <div className="py-8 text-center text-slate-500">No players registered yet.</div>
          ) : (
            <div className="divide-y divide-slate-800">
              {participants.map((p, idx) => (
                <div key={p.id} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-500 w-5">#{idx + 1}</span>
                    <div>
                      <h4 className="font-bold text-white font-gaming">{p.playerName}</h4>
                      <p className="text-[10px] text-slate-400 font-mono">
                        UID: {p.ffUid} {p.teamName ? `• Team: ${p.teamName}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-md">
                      {p.paymentStatus}
                    </span>
                    <button
                      onClick={() => handleRemove(p.userId, p.playerName)}
                      className="p-1 rounded-md hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                      title="Remove Player"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Sub-component: Results Publisher Modal
const ResultsPublisherModal: React.FC<{ tournament: Tournament; onClose: () => void }> = ({ tournament, onClose }) => {
  const { showToast, refreshAll } = useApp();
  const [participants, setParticipants] = useState<any[]>([]);
  const [entries, setEntries] = useState<Array<{
    userId?: string;
    playerName: string;
    ffUid: string;
    rank: number;
    kills: number;
    score: number;
    prize: number;
  }>>([]);
  const [isPublishing, setIsPublishing] = useState(false);

  React.useEffect(() => {
    api.getParticipants(tournament.id).then((pts) => {
      setParticipants(pts);
      // Prepopulate entries based on participants or default template
      if (pts.length > 0) {
        setEntries(
          pts.map((p, i) => ({
            userId: p.userId,
            playerName: p.playerName,
            ffUid: p.ffUid,
            rank: i + 1,
            kills: 0,
            score: 100 - i * 10,
            prize: i === 0 ? tournament.prizeDistribution.rank1 : i === 1 ? tournament.prizeDistribution.rank2 : i === 2 ? tournament.prizeDistribution.rank3 : 0,
          }))
        );
      } else {
        // Fallback demo rows
        setEntries([
          { playerName: '⚡RAKIB_FF⚡', ffUid: '839201948', rank: 1, kills: 7, score: 185, prize: tournament.prizeDistribution.rank1 },
          { playerName: '亗SHADOW亗', ffUid: '910283741', rank: 2, kills: 4, score: 140, prize: tournament.prizeDistribution.rank2 },
          { playerName: 'ApexSniper', ffUid: '629104822', rank: 3, kills: 2, score: 110, prize: tournament.prizeDistribution.rank3 },
        ]);
      }
    });
  }, [tournament]);

  const updateEntry = (idx: number, field: string, val: any) => {
    setEntries((prev) => {
      const copy = [...prev];
      copy[idx] = { ...copy[idx], [field]: val };
      return copy;
    });
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsPublishing(true);
      await api.publishResults(tournament.id, entries);
      showToast('🏆 Results published! Prizes credited to winner wallets automatically.', 'success');
      refreshAll();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to publish results', 'error');
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white max-h-[90vh] flex flex-col">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div>
            <h3 className="font-black text-base font-gaming tracking-wide uppercase text-amber-300">
              PUBLISH MATCH RESULTS & WINNER REWARDS
            </h3>
            <p className="text-[11px] text-slate-400">
              {tournament.title} • Automated Wallet Prize Credit
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handlePublish} className="p-4 overflow-y-auto space-y-3 flex-1 text-xs">
          <div className="bg-amber-950/30 border border-amber-500/30 p-2.5 rounded-xl text-amber-200 text-[11px]">
            ⚡ Submitting results will set tournament status to <strong>Completed</strong> and automatically add prizes to winners' wallets!
          </div>

          <div className="space-y-2">
            {entries.map((entry, idx) => (
              <div key={idx} className="p-3 bg-slate-800 rounded-xl border border-slate-700 grid grid-cols-6 gap-2 items-center">
                <div className="col-span-2">
                  <label className="text-[10px] text-slate-400 block">Player</label>
                  <input
                    type="text"
                    value={entry.playerName}
                    onChange={(e) => updateEntry(idx, 'playerName', e.target.value)}
                    className="w-full bg-slate-900 px-2 py-1 rounded-md text-white font-gaming font-bold"
                  />
                  <span className="text-[9px] text-slate-400 font-mono">UID: {entry.ffUid}</span>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block">Rank #</label>
                  <input
                    type="number"
                    value={entry.rank}
                    onChange={(e) => updateEntry(idx, 'rank', Number(e.target.value))}
                    className="w-full bg-slate-900 px-2 py-1 rounded-md text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block">Kills</label>
                  <input
                    type="number"
                    value={entry.kills}
                    onChange={(e) => updateEntry(idx, 'kills', Number(e.target.value))}
                    className="w-full bg-slate-900 px-2 py-1 rounded-md text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block">Score</label>
                  <input
                    type="number"
                    value={entry.score}
                    onChange={(e) => updateEntry(idx, 'score', Number(e.target.value))}
                    className="w-full bg-slate-900 px-2 py-1 rounded-md text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-amber-400 block font-bold">Prize (৳)</label>
                  <input
                    type="number"
                    value={entry.prize}
                    onChange={(e) => updateEntry(idx, 'prize', Number(e.target.value))}
                    className="w-full bg-slate-900 px-2 py-1 rounded-md text-amber-400 font-bold"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isPublishing}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black font-gaming uppercase tracking-wider"
            >
              {isPublishing ? 'Publishing...' : 'Publish & Credit Wallets'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
