import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Megaphone, Send, Users, Swords, Bell, CheckCircle2 } from 'lucide-react';

export const AdminNotifications: React.FC = () => {
  const { notifications, tournaments, users, refreshAll, showToast } = useApp();

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [target, setTarget] = useState<'all' | 'tournament' | 'user'>('all');
  const [targetId, setTargetId] = useState('');
  const [type, setType] = useState<'announcement' | 'tournament' | 'room' | 'wallet'>('announcement');
  const [isSending, setIsSending] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      showToast('Title and message are required', 'error');
      return;
    }

    try {
      setIsSending(true);
      await api.sendNotification({
        title: title.trim(),
        message: message.trim(),
        target,
        targetId: target !== 'all' ? targetId : undefined,
        type,
      });

      showToast('🚀 Push notification broadcasted to players!', 'success');
      setTitle('');
      setMessage('');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to broadcast', 'error');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
          NOTIFICATION & BROADCAST CENTER
        </h2>
        <p className="text-xs text-slate-400">
          Send in-app alerts, tournament reminders, room credentials bulletins, and urgent updates.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Broadcast Composer */}
        <div className="bg-slate-900 rounded-3xl p-5 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Megaphone className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-sm text-white uppercase font-gaming">
              Compose Push Broadcast
            </h3>
          </div>

          <form onSubmit={handleSend} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Target Audience:</label>
              <div className="grid grid-cols-3 gap-2">
                {(['all', 'tournament', 'user'] as const).map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => {
                      setTarget(t);
                      setTargetId(t === 'tournament' ? (tournaments[0]?.id || '') : (users[0]?.id || ''));
                    }}
                    className={`p-2 rounded-xl border text-center font-bold capitalize transition-all ${
                      target === t
                        ? 'border-purple-500 bg-purple-600/30 text-purple-200'
                        : 'border-slate-800 bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {t === 'all' ? 'All Players' : t === 'tournament' ? 'Tournament Lobby' : 'Specific Player'}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Selector */}
            {target === 'tournament' && (
              <div>
                <label className="block font-bold text-slate-300 mb-1">Select Tournament:</label>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white outline-hidden"
                >
                  {tournaments.map((trn) => (
                    <option key={trn.id} value={trn.id}>
                      {trn.title} ({trn.gameMode})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {target === 'user' && (
              <div>
                <label className="block font-bold text-slate-300 mb-1">Select Target Player:</label>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white outline-hidden"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.username} (UID: {u.ffUid})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block font-bold text-slate-300 mb-1">Notification Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Room ID Published! Match starting in 10 mins"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming text-sm text-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Message Content *</label>
              <textarea
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter details for players..."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden text-white"
              />
            </div>

            <button
              type="submit"
              disabled={isSending}
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>{isSending ? 'Broadcasting...' : 'Broadcast Notification Now'}</span>
            </button>
          </form>
        </div>

        {/* Broadcast History */}
        <div className="bg-slate-900 rounded-3xl p-5 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-extrabold text-sm text-white uppercase font-gaming">
              Broadcast Log ({notifications.length})
            </h3>
            <span className="text-[11px] text-slate-400">Live feed</span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1 text-xs">
            {notifications.map((n) => (
              <div
                key={n.id}
                className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white font-gaming">{n.title}</h4>
                  <span className="bg-purple-900/60 text-purple-300 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
                    {n.target}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">{n.message}</p>
                <div className="text-[10px] text-slate-500 font-mono pt-1">
                  {new Date(n.timestamp).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
