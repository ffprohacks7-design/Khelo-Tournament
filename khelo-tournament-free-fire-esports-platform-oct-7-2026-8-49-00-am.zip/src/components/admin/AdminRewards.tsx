import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Wallet, CheckCircle, XCircle, Clock, Search, ArrowDownLeft, ArrowUpRight, Trophy, CreditCard } from 'lucide-react';

export const AdminRewards: React.FC = () => {
  const { transactions, refreshAll, showToast } = useApp();

  const [filter, setFilter] = useState<'all' | 'pending' | 'deposits' | 'withdrawals'>('all');
  const [search, setSearch] = useState('');

  const filteredTxns = transactions.filter((tx) => {
    if (filter === 'pending' && tx.status !== 'Pending') return false;
    if (filter === 'deposits' && tx.type !== 'Deposit') return false;
    if (filter === 'withdrawals' && tx.type !== 'Withdrawal') return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        tx.id.toLowerCase().includes(q) ||
        tx.userName.toLowerCase().includes(q) ||
        tx.userId.toLowerCase().includes(q) ||
        tx.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleReview = async (id: string, status: 'Approved' | 'Rejected') => {
    try {
      await api.reviewTransaction(id, status);
      showToast(`Transaction ${id} marked as ${status}`, 'success');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Review failed', 'error');
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
            REWARDS & WALLET MANAGEMENT
          </h2>
          <p className="text-xs text-slate-400">
            Review player deposit proofs, approve prize payouts, and audit transaction records.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-bold text-slate-400">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'all' ? 'bg-purple-600 text-white' : 'hover:text-white'}`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 ${filter === 'pending' ? 'bg-amber-600 text-white' : 'hover:text-white'}`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Pending</span>
          </button>
          <button
            onClick={() => setFilter('deposits')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'deposits' ? 'bg-emerald-600 text-white' : 'hover:text-white'}`}
          >
            Deposits
          </button>
          <button
            onClick={() => setFilter('withdrawals')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'withdrawals' ? 'bg-rose-600 text-white' : 'hover:text-white'}`}
          >
            Withdrawals
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-gaming text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Transaction ID</th>
                <th className="p-3.5">User</th>
                <th className="p-3.5">Type & Gateway</th>
                <th className="p-3.5">Amount</th>
                <th className="p-3.5">Date / Time</th>
                <th className="p-3.5">Description</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredTxns.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    No transactions match your current filter.
                  </td>
                </tr>
              ) : (
                filteredTxns.map((tx) => {
                  const isPositive = tx.amount > 0;

                  return (
                    <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-amber-300">
                        {tx.id}
                      </td>

                      <td className="p-3.5">
                        <div className="font-bold text-white font-gaming">{tx.userName}</div>
                        <div className="text-[10px] text-slate-500 font-mono">UID: {tx.userId}</div>
                      </td>

                      <td className="p-3.5">
                        <span className="font-semibold text-slate-200 block">{tx.type}</span>
                        {tx.paymentMethod && (
                          <span className="text-[10px] text-slate-400">
                            {tx.paymentMethod} ({tx.accountNumber || '—'})
                          </span>
                        )}
                      </td>

                      <td className="p-3.5">
                        <span className={`font-black text-sm font-gaming ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isPositive ? `+৳${tx.amount}` : `-৳${Math.abs(tx.amount)}`}
                        </span>
                      </td>

                      <td className="p-3.5 text-[11px] text-slate-400">
                        {tx.date} • {tx.time}
                      </td>

                      <td className="p-3.5 max-w-xs truncate text-slate-300">
                        {tx.description}
                      </td>

                      <td className="p-3.5">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          tx.status === 'Approved' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          tx.status === 'Pending' ? 'bg-amber-950 text-amber-400 border border-amber-800 animate-pulse' :
                          'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}>
                          {tx.status}
                        </span>
                      </td>

                      <td className="p-3.5 text-right">
                        {tx.status === 'Pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleReview(tx.id, 'Approved')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1"
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                              Approve
                            </button>
                            <button
                              onClick={() => handleReview(tx.id, 'Rejected')}
                              className="px-2.5 py-1 rounded-lg bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold text-[11px] flex items-center gap-1"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Reject
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-500 text-[11px]">Reviewed</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
