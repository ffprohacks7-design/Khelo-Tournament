import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Settings, Save, AlertTriangle, ShieldCheck, Send, Phone, Megaphone } from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { settings, refreshAll, showToast } = useApp();

  const [appName, setAppName] = useState(settings?.appName || 'KHelo Tournament');
  const [telegramLink, setTelegramLink] = useState(settings?.telegramLink || 'https://t.me/khelobangladesh_live');
  const [telegramChannelName, setTelegramChannelName] = useState(settings?.telegramChannelName || '@khelobangladesh_live');
  const [whatsappSupport, setWhatsappSupport] = useState(settings?.whatsappSupport || '+8801700000000');
  const [supportEmail, setSupportEmail] = useState(settings?.supportEmail || 'support@khelo.gg');
  const [marqueeNoticeEn, setMarqueeNoticeEn] = useState(settings?.marqueeNoticeEn || '');
  const [marqueeNoticeBn, setMarqueeNoticeBn] = useState(settings?.marqueeNoticeBn || '');
  const [maintenanceMode, setMaintenanceMode] = useState(settings?.maintenanceMode || false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setAppName(settings.appName);
      setTelegramLink(settings.telegramLink);
      setTelegramChannelName(settings.telegramChannelName);
      setWhatsappSupport(settings.whatsappSupport);
      setSupportEmail(settings.supportEmail);
      setMarqueeNoticeEn(settings.marqueeNoticeEn);
      setMarqueeNoticeBn(settings.marqueeNoticeBn);
      setMaintenanceMode(settings.maintenanceMode);
    }
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSaving(true);
      await api.updateSettings({
        appName,
        telegramLink,
        telegramChannelName,
        whatsappSupport,
        supportEmail,
        marqueeNoticeEn,
        marqueeNoticeBn,
        maintenanceMode,
      });
      showToast('System settings saved successfully!', 'success');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to save settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
          SYSTEM CONFIGURATION & APP SETTINGS
        </h2>
        <p className="text-xs text-slate-400">
          Manage branding, official Telegram community channels, announcement marquee banners, and maintenance mode.
        </p>
      </div>

      <form onSubmit={handleSave} className="bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-xl space-y-5 text-xs">
        {/* App Branding */}
        <div className="space-y-3">
          <h3 className="font-extrabold text-sm text-amber-300 uppercase font-gaming flex items-center gap-1.5 pb-2 border-b border-slate-800">
            <Settings className="w-4 h-4 text-purple-400" />
            General Branding
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Application Name</label>
              <input
                type="text"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-gaming text-sm font-bold focus:border-purple-500 outline-hidden"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-300 mb-1">Official Support Email</label>
              <input
                type="email"
                value={supportEmail}
                onChange={(e) => setSupportEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-purple-500 outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Telegram & WhatsApp Community Links */}
        <div className="space-y-3">
          <h3 className="font-extrabold text-sm text-cyan-300 uppercase font-gaming flex items-center gap-1.5 pb-2 border-b border-slate-800">
            <Send className="w-4 h-4 text-cyan-400" />
            Community & Telegram Integration
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Telegram Handle</label>
              <input
                type="text"
                value={telegramChannelName}
                onChange={(e) => setTelegramChannelName(e.target.value)}
                placeholder="@khelobangladesh_live"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-cyan-300 font-mono font-bold focus:border-purple-500 outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Telegram URL</label>
              <input
                type="text"
                value={telegramLink}
                onChange={(e) => setTelegramLink(e.target.value)}
                placeholder="https://t.me/..."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono focus:border-purple-500 outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">WhatsApp Helpline</label>
              <input
                type="text"
                value={whatsappSupport}
                onChange={(e) => setWhatsappSupport(e.target.value)}
                placeholder="+8801700000000"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-emerald-400 font-mono focus:border-purple-500 outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Marquee Notices (English & Bengali) */}
        <div className="space-y-3">
          <h3 className="font-extrabold text-sm text-yellow-300 uppercase font-gaming flex items-center gap-1.5 pb-2 border-b border-slate-800">
            <Megaphone className="w-4 h-4 text-yellow-400" />
            Home Screen Marquee Announcement
          </h3>

          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="block font-bold text-slate-300 mb-1">
                Bengali Notice (বাংলা নোটিশ) - as shown in reference:
              </label>
              <input
                type="text"
                value={marqueeNoticeBn}
                onChange={(e) => setMarqueeNoticeBn(e.target.value)}
                placeholder="কম দামে ডায়মন্ড টপ আপ করতে নিচে Shop বাটনে ক্লিক করুন।"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-yellow-300 font-bengali text-sm focus:border-purple-500 outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">
                English Notice (English text):
              </label>
              <input
                type="text"
                value={marqueeNoticeEn}
                onChange={(e) => setMarqueeNoticeEn(e.target.value)}
                placeholder="Top up Free Fire Diamonds at cheapest rate by clicking Shop below!"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-purple-500 outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Maintenance Mode */}
        <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <h4 className="font-bold text-white">Maintenance Mode</h4>
              <p className="text-[11px] text-slate-400">
                When enabled, pauses tournament registrations for scheduled room maintenance.
              </p>
            </div>
          </div>

          <input
            type="checkbox"
            checked={maintenanceMode}
            onChange={(e) => setMaintenanceMode(e.target.checked)}
            className="w-5 h-5 accent-purple-600 rounded-md cursor-pointer"
          />
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-sm uppercase tracking-wider font-gaming shadow-md transition-all active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
