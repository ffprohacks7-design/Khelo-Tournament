import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { User } from '../../types';
import { api } from '../../services/api';
import { Users, Search, ShieldCheck, ShieldAlert, Edit2, Wallet, Plus, Minus, X, Trash2, Check } from 'lucide-react';

export const AdminPlayers: React.FC = () => {
  const { users, refreshAll, showToast } = useApp();

  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [balanceModalUser, setBalanceModalUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState('50');
  const [adjustNote, setAdjustNote] = useState('Tournament participation reward');

  const filteredUsers = users.filter((u) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.ffUid.includes(q) ||
      u.id.toLowerCase().includes(q)
    );
  });

  const handleToggleStatus = async (user: User) => {
    const nextStatus = user.status === 'Active' ? 'Suspended' : 'Active';
    try {
      await api.updateUser(user.id, { status: nextStatus });
      showToast(`User ${user.username} is now ${nextStatus}`, 'success');
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Failed to update user', 'error');
    }
  };

  const handleAdjustBalance = async (e: React.FormEvent, isCredit: boolean) => {
    e.preventDefault();
    if (!balanceModalUser) return;
    const num = Number(adjustAmount);
    if (!num || num <= 0) return;

    try {
      await api.adjustWallet({
        userId: balanceModalUser.id,
        amount: isCredit ? num : -num,
        description: adjustNote.trim() || (isCredit ? 'Admin Bonus Reward' : 'Admin Balance Adjustment'),
      });
      showToast(`Wallet adjusted by ${isCredit ? '+' : '-'}৳${num} for ${balanceModalUser.username}`, 'success');
      setBalanceModalUser(null);
      refreshAll();
    } catch (err: any) {
      showToast(err.message || 'Adjustment failed', 'error');
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-gaming uppercase tracking-wide">
            PLAYER MANAGEMENT
          </h2>
          <p className="text-xs text-slate-400">
            View registered players, inspect Free Fire UIDs, control account status, and grant wallet bonuses.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, UID, email..."
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-purple-500"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-gaming text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">User / In-Game Name</th>
                <th className="p-3.5">Free Fire UID</th>
                <th className="p-3.5">Contact</th>
                <th className="p-3.5">Wallet</th>
                <th className="p-3.5">Career Stats</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={u.avatar}
                        alt={u.username}
                        className="w-9 h-9 rounded-xl bg-purple-900/40 border border-purple-500/30 object-cover shrink-0"
                      />
                      <div>
                        <div className="font-bold text-white font-gaming flex items-center gap-1.5">
                          <span>{u.inGameName || u.username}</span>
                          {u.role === 'admin' && (
                            <span className="bg-purple-900 text-purple-300 text-[9px] px-1.5 py-0.2 rounded-sm font-sans font-bold">
                              ADMIN
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          ID: {u.id}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="p-3.5">
                    <span className="font-mono font-bold text-amber-300 bg-slate-950 px-2 py-1 rounded-md border border-slate-800">
                      {u.ffUid || 'Not set'}
                    </span>
                  </td>

                  <td className="p-3.5">
                    <div className="text-[11px] text-slate-300 font-medium">{u.email}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{u.phone || 'No phone'}</div>
                  </td>

                  <td className="p-3.5">
                    <div className="font-black text-emerald-400 font-gaming text-sm">
                      ৳{u.walletBalance}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Won: ৳{u.totalEarnings}
                    </div>
                  </td>

                  <td className="p-3.5">
                    <div className="text-[11px] font-bold text-white font-gaming">
                      {u.totalMatches} Matches • {u.totalWins} Wins
                    </div>
                    <div className="text-[10px] text-emerald-400">
                      {u.winRate}% Win rate
                    </div>
                  </td>

                  <td className="p-3.5">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      u.status === 'Active'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}>
                      {u.status}
                    </span>
                  </td>

                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setBalanceModalUser(u)}
                        className="px-2 py-1 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-[11px] font-bold flex items-center gap-1"
                        title="Adjust Wallet"
                      >
                        <Wallet className="w-3 h-3" />
                        <span>Adjust</span>
                      </button>

                      <button
                        onClick={() => handleToggleStatus(u)}
                        className={`px-2 py-1 rounded-lg text-[11px] font-bold ${
                          u.status === 'Active'
                            ? 'bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800'
                            : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800'
                        }`}
                      >
                        {u.status === 'Active' ? 'Suspend' : 'Activate'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADJUST WALLET MODAL */}
      {balanceModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden text-white animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base font-gaming tracking-wide uppercase text-white">
                  ADJUST PLAYER WALLET
                </h3>
              </div>
              <button
                onClick={() => setBalanceModalUser(null)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white font-gaming text-sm">{balanceModalUser.username}</h4>
                  <p className="text-[10px] text-slate-400">UID: {balanceModalUser.ffUid}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Current Balance</span>
                  <span className="font-black text-base text-emerald-400 font-gaming">৳{balanceModalUser.walletBalance}</span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Adjustment Amount (৳):</label>
                <input
                  type="number"
                  min={1}
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden font-gaming text-base font-bold text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Reason / Description:</label>
                <input
                  type="text"
                  value={adjustNote}
                  onChange={(e) => setAdjustNote(e.target.value)}
                  placeholder="e.g. Tournament 1st place prize, Compensation"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:border-purple-500 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={(e) => handleAdjustBalance(e, true)}
                  className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-1.5 font-gaming uppercase tracking-wider shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Credit (+৳{adjustAmount})</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => handleAdjustBalance(e, false)}
                  className="py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center justify-center gap-1.5 font-gaming uppercase tracking-wider shadow-md"
                >
                  <Minus className="w-4 h-4" />
                  <span>Debit (-৳{adjustAmount})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
