export type GameMode = 
  | 'BR Match'
  | 'BR Survival'
  | 'Clash Squad'
  | 'CS 2 VS 2'
  | 'Lone Wolf'
  | 'Free Match'
  | 'Custom Room';

export type MatchType = 'Solo' | 'Duo' | 'Squad';

export type TournamentStatus = 
  | 'Upcoming'
  | 'Registration Open'
  | 'Full'
  | 'Live'
  | 'Completed'
  | 'Cancelled';

export interface Tournament {
  id: string;
  title: string;
  gameMode: GameMode;
  matchType: MatchType;
  map: string; // Bermuda, Purgatory, Kalahari, Alpine, NexTerra
  bannerImage: string;
  description: string;
  rules: string;
  entryFee: number; // in BDT (৳) or Coins
  prizePool: number;
  perKillPrize: number;
  prizeDistribution: {
    rank1: number;
    rank2: number;
    rank3: number;
    perKill: number;
  };
  maxSlots: number;
  joinedSlots: number;
  matchDate: string; // YYYY-MM-DD
  matchTime: string; // e.g. "08:30 PM"
  roomId?: string;
  roomPassword?: string;
  isRoomPublished: boolean;
  status: TournamentStatus;
  createdAt: string;
}

export interface Participant {
  id: string;
  tournamentId: string;
  userId: string;
  playerName: string; // In-Game Name (IGN)
  ffUid: string;      // Free Fire UID
  teamName?: string;
  joinTime: string;
  paymentStatus: 'Paid' | 'Free' | 'Pending';
  status: 'Confirmed' | 'Disqualified' | 'Pending';
}

export interface MatchResult {
  id: string;
  tournamentId: string;
  userId?: string;
  playerName: string;
  ffUid: string;
  rank: number;
  kills: number;
  score: number;
  prize: number;
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  ffUid: string;
  inGameName: string;
  avatar: string;
  role: 'user' | 'admin';
  walletBalance: number;
  totalEarnings: number;
  totalMatches: number;
  totalWins: number;
  winRate: number;
  status: 'Active' | 'Suspended';
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  type: 'Entry Fee' | 'Match Reward' | 'Deposit' | 'Withdrawal' | 'Admin Bonus';
  amount: number;
  currency: string;
  date: string;
  time: string;
  status: 'Approved' | 'Pending' | 'Rejected';
  description: string;
  paymentMethod?: string;
  accountNumber?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  imageUrl: string;
  actionUrl?: string;
  actionType: 'telegram' | 'tournament' | 'shop' | 'external';
  order: number;
  isActive: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  target: 'all' | 'tournament' | 'user';
  targetId?: string;
  timestamp: string;
  isRead: boolean;
  type: 'tournament' | 'room' | 'result' | 'wallet' | 'announcement';
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  subject: string;
  message: string;
  status: 'Open' | 'Resolved';
  timestamp: string;
}

export interface AppSettings {
  appName: string;
  telegramLink: string;
  telegramChannelName: string;
  whatsappSupport: string;
  supportEmail: string;
  marqueeNoticeEn: string;
  marqueeNoticeBn: string;
  maintenanceMode: boolean;
  defaultCurrency: string;
  minWithdrawal: number;
}
