import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { 
  User, 
  Tournament, 
  Banner, 
  NotificationItem, 
  Transaction, 
  MatchResult, 
  AppSettings, 
  Participant,
  GameMode 
} from '../types';
import { api } from '../services/api';
import { translations, Language } from '../translations';
import { 
  initialTournaments, 
  initialBanners, 
  initialUsers, 
  initialResults, 
  initialTransactions, 
  initialNotifications, 
  initialSettings 
} from '../data/seedData';

interface ToastInfo {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  users: User[];
  viewMode: 'user' | 'admin';
  setViewMode: (mode: 'user' | 'admin') => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations['en'];
  
  // Data
  tournaments: Tournament[];
  banners: Banner[];
  notifications: NotificationItem[];
  transactions: Transaction[];
  results: MatchResult[];
  participants: Participant[];
  settings: AppSettings;
  unreadCount: number;
  isLoading: boolean;
  
  // Navigation & Modals
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedCategory: GameMode | 'ALL';
  setSelectedCategory: (cat: GameMode | 'ALL') => void;
  selectedTournament: Tournament | null;
  setSelectedTournament: (trn: Tournament | null) => void;
  
  isDetailOpen: boolean;
  setIsDetailOpen: (open: boolean) => void;
  isJoinModalOpen: boolean;
  setIsJoinModalOpen: (open: boolean) => void;
  isWalletModalOpen: boolean;
  setIsWalletModalOpen: (open: boolean) => void;
  isSupportModalOpen: boolean;
  setIsSupportModalOpen: (open: boolean) => void;
  isShopModalOpen: boolean;
  setIsShopModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isNotifDrawerOpen: boolean;
  setIsNotifDrawerOpen: (open: boolean) => void;
  
  // Device Frame View (Mobile Phone vs Full Screen)
  devicePreviewMode: 'mobile' | 'fullscreen';
  setDevicePreviewMode: (mode: 'mobile' | 'fullscreen') => void;

  // Actions
  refreshAll: () => Promise<void>;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  toasts: ToastInfo[];
  removeToast: (id: string) => void;
  joinTournament: (trnId: string, details: { playerName: string; ffUid: string; teamName?: string }) => Promise<boolean>;
  login: (login: string, pass?: string, role?: string) => Promise<boolean>;
  logout: () => void;
  register: (data: Partial<User>) => Promise<boolean>;
  updateUserProfile: (data: Partial<User>) => Promise<boolean>;
  markNotifAsRead: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(initialUsers[0]); // default to demo player Rakib
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [viewMode, setViewMode] = useState<'user' | 'admin'>('user');
  const [language, setLanguage] = useState<Language>('bn'); // default to Bengali/English matching reference screenshot
  const [tournaments, setTournaments] = useState<Tournament[]>(initialTournaments);
  const [banners, setBanners] = useState<Banner[]>(initialBanners);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [results, setResults] = useState<MatchResult[]>(initialResults);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [settings, setSettings] = useState<AppSettings>(initialSettings);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastInfo[]>([]);

  // Navigation
  const [activeTab, setActiveTab] = useState<string>('play');
  const [selectedCategory, setSelectedCategory] = useState<GameMode | 'ALL'>('ALL');
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);

  // Modals
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [isShopModalOpen, setIsShopModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isNotifDrawerOpen, setIsNotifDrawerOpen] = useState(false);

  // Responsive vs Android phone view frame
  const [devicePreviewMode, setDevicePreviewMode] = useState<'mobile' | 'fullscreen'>('mobile');

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3800);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const refreshAll = useCallback(async () => {
    try {
      setIsLoading(true);
      const [tData, bData, nData, sData, rData, uData] = await Promise.allSettled([
        api.getTournaments(),
        api.getBanners(),
        api.getNotifications(),
        api.getSettings(),
        api.getResults(),
        api.getUsers(),
      ]);

      if (tData.status === 'fulfilled') setTournaments(tData.value);
      if (bData.status === 'fulfilled') setBanners(bData.value);
      if (nData.status === 'fulfilled') setNotifications(nData.value);
      if (sData.status === 'fulfilled') setSettings(sData.value);
      if (rData.status === 'fulfilled') setResults(rData.value);
      if (uData.status === 'fulfilled') {
        setUsers(uData.value);
        // Sync currentUser if exists
        if (currentUser) {
          const fresh = uData.value.find((u) => u.id === currentUser.id);
          if (fresh) setCurrentUser(fresh);
        }
      }

      if (currentUser) {
        const txData = await api.getTransactions(currentUser.role === 'admin' ? undefined : currentUser.id).catch(() => []);
        setTransactions(txData);
      }
    } catch (err) {
      console.warn('Backend sync failed, using local state:', err);
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  // Initial load
  useEffect(() => {
    refreshAll();
  }, []);

  const login = async (loginId: string, pass?: string, role?: string): Promise<boolean> => {
    try {
      const res = await api.login(loginId, pass, role);
      setCurrentUser(res.user);
      if (res.user.role === 'admin') {
        setViewMode('admin');
      }
      showToast(`Welcome back, ${res.user.name}! 🎮`, 'success');
      refreshAll();
      return true;
    } catch (err: any) {
      showToast(err.message || 'Login failed', 'error');
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setViewMode('user');
    showToast('Logged out successfully', 'info');
  };

  const register = async (data: Partial<User>): Promise<boolean> => {
    try {
      const res = await api.register(data);
      setCurrentUser(res.user);
      showToast(`Account created! Welcome bonus ৳${res.user.walletBalance} credited! 🎁`, 'success');
      refreshAll();
      return true;
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      return false;
    }
  };

  const updateUserProfile = async (data: Partial<User>): Promise<boolean> => {
    if (!currentUser) return false;
    try {
      const updated = await api.updateUser(currentUser.id, data);
      setCurrentUser(updated);
      showToast('Profile updated successfully!', 'success');
      refreshAll();
      return true;
    } catch (err: any) {
      showToast(err.message || 'Update failed', 'error');
      return false;
    }
  };

  const joinTournament = async (
    trnId: string, 
    details: { playerName: string; ffUid: string; teamName?: string }
  ): Promise<boolean> => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      showToast('Please login to join tournament', 'info');
      return false;
    }

    try {
      const res = await api.joinTournament(trnId, {
        userId: currentUser.id,
        playerName: details.playerName,
        ffUid: details.ffUid,
        teamName: details.teamName,
      });

      if (res.success) {
        showToast(`🎉 Registered for ${res.tournament.title}!`, 'success');
        setCurrentUser(res.user);
        setSelectedTournament(res.tournament);
        refreshAll();
        return true;
      }
      return false;
    } catch (err: any) {
      showToast(err.message || 'Could not join tournament', 'error');
      return false;
    }
  };

  const markNotifAsRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
      );
    } catch {
      // ignore
    }
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const t = translations[language];

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        users,
        viewMode,
        setViewMode,
        language,
        setLanguage,
        t,
        tournaments,
        banners,
        notifications,
        transactions,
        results,
        participants,
        settings,
        unreadCount,
        isLoading,
        activeTab,
        setActiveTab,
        selectedCategory,
        setSelectedCategory,
        selectedTournament,
        setSelectedTournament,
        isDetailOpen,
        setIsDetailOpen,
        isJoinModalOpen,
        setIsJoinModalOpen,
        isWalletModalOpen,
        setIsWalletModalOpen,
        isSupportModalOpen,
        setIsSupportModalOpen,
        isShopModalOpen,
        setIsShopModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isNotifDrawerOpen,
        setIsNotifDrawerOpen,
        devicePreviewMode,
        setDevicePreviewMode,
        refreshAll,
        showToast,
        toasts,
        removeToast,
        joinTournament,
        login,
        logout,
        register,
        updateUserProfile,
        markNotifAsRead,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
