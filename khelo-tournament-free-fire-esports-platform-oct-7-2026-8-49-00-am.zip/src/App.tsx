/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { UserView } from './components/user/UserView';
import { AdminView } from './components/admin/AdminView';
import { ToastContainer } from './components/common/ToastContainer';

function MainRouter() {
  const { viewMode } = useApp();

  return (
    <>
      <ToastContainer />
      {viewMode === 'admin' ? <AdminView /> : <UserView />}
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainRouter />
    </AppProvider>
  );
}
