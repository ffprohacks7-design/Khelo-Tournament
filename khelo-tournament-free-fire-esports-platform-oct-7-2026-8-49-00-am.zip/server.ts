import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { 
  initialTournaments, 
  initialBanners, 
  initialUsers, 
  initialResults, 
  initialTransactions, 
  initialNotifications, 
  initialSettings,
  initialSupportTickets 
} from './src/data/seedData';
import { Tournament, User, Banner, NotificationItem, Transaction, MatchResult, AppSettings, SupportTicket, Participant } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory state
interface Database {
  tournaments: Tournament[];
  banners: Banner[];
  users: User[];
  participants: Participant[];
  results: MatchResult[];
  transactions: Transaction[];
  notifications: NotificationItem[];
  settings: AppSettings;
  supportTickets: SupportTicket[];
}

function loadDB(): Database {
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(raw);
    } catch (e) {
      console.error('Error reading db.json, fallback to seed data:', e);
    }
  }

  // Create initial participants from seed data
  const seedParticipants: Participant[] = [
    {
      id: 'PT-1',
      tournamentId: 'TRN-101',
      userId: 'USR-89421',
      playerName: '⚡RAKIB_FF⚡',
      ffUid: '839201948',
      teamName: 'Team Viper',
      joinTime: '2026-10-06T14:15:00Z',
      paymentStatus: 'Paid',
      status: 'Confirmed'
    },
    {
      id: 'PT-2',
      tournamentId: 'TRN-101',
      userId: 'USR-77312',
      playerName: '亗SHADOW亗',
      ffUid: '910283741',
      teamName: 'Shadow Clan',
      joinTime: '2026-10-06T14:30:00Z',
      paymentStatus: 'Paid',
      status: 'Confirmed'
    },
    {
      id: 'PT-3',
      tournamentId: 'TRN-104',
      userId: 'USR-89421',
      playerName: '⚡RAKIB_FF⚡',
      ffUid: '839201948',
      teamName: 'Duo Apex',
      joinTime: '2026-10-06T16:00:00Z',
      paymentStatus: 'Paid',
      status: 'Confirmed'
    },
    {
      id: 'PT-4',
      tournamentId: 'TRN-105',
      userId: 'USR-89421',
      playerName: '⚡RAKIB_FF⚡',
      ffUid: '839201948',
      joinTime: '2026-10-05T18:00:00Z',
      paymentStatus: 'Paid',
      status: 'Confirmed'
    },
    {
      id: 'PT-5',
      tournamentId: 'TRN-105',
      userId: 'USR-77312',
      playerName: '亗SHADOW亗',
      ffUid: '910283741',
      joinTime: '2026-10-05T18:05:00Z',
      paymentStatus: 'Paid',
      status: 'Confirmed'
    }
  ];

  const db: Database = {
    tournaments: initialTournaments,
    banners: initialBanners,
    users: initialUsers,
    participants: seedParticipants,
    results: initialResults,
    transactions: initialTransactions,
    notifications: initialNotifications,
    settings: initialSettings,
    supportTickets: initialSupportTickets
  };

  saveDB(db);
  return db;
}

function saveDB(db: Database) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write db.json:', err);
  }
}

let db = loadDB();

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  const router = express.Router();

  // Settings
  router.get('/settings', (req, res) => {
    res.json(db.settings);
  });

  router.put('/settings', (req, res) => {
    db.settings = { ...db.settings, ...req.body };
    saveDB(db);
    res.json(db.settings);
  });

  // Banners
  router.get('/banners', (req, res) => {
    const sorted = [...db.banners].sort((a, b) => a.order - b.order);
    res.json(sorted);
  });

  router.post('/banners', (req, res) => {
    const newBanner: Banner = {
      id: `BAN-${Date.now().toString().slice(-5)}`,
      title: req.body.title || 'Special Event',
      subtitle: req.body.subtitle || '',
      imageUrl: req.body.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1000&q=80',
      actionUrl: req.body.actionUrl || '#',
      actionType: req.body.actionType || 'tournament',
      order: db.banners.length + 1,
      isActive: req.body.isActive !== false,
    };
    db.banners.push(newBanner);
    saveDB(db);
    res.json(newBanner);
  });

  router.put('/banners/:id', (req, res) => {
    const idx = db.banners.findIndex(b => b.id === req.params.id);
    if (idx !== -1) {
      db.banners[idx] = { ...db.banners[idx], ...req.body };
      saveDB(db);
      res.json(db.banners[idx]);
    } else {
      res.status(404).json({ error: 'Banner not found' });
    }
  });

  router.delete('/banners/:id', (req, res) => {
    db.banners = db.banners.filter(b => b.id !== req.params.id);
    saveDB(db);
    res.json({ success: true });
  });

  // Users & Auth
  router.post('/auth/login', (req, res) => {
    const { login, password } = req.body;
    // For admin shortcut or password matching
    if (login === 'admin@khelo.gg' || login === 'admin' || (password === 'admin123' && req.body.role === 'admin')) {
      const adminUser = db.users.find(u => u.role === 'admin') || db.users[2];
      return res.json({ user: adminUser, token: 'mock-admin-token' });
    }

    const user = db.users.find(u => 
      u.email.toLowerCase() === (login || '').toLowerCase() || 
      u.username.toLowerCase() === (login || '').toLowerCase() ||
      u.phone === login
    );

    if (user) {
      res.json({ user, token: `mock-token-${user.id}` });
    } else {
      // Auto-fallback for demo if desired, or return 401
      res.status(401).json({ error: 'Invalid username, phone, or password' });
    }
  });

  router.post('/auth/register', (req, res) => {
    const { name, username, email, phone, ffUid, inGameName, avatar } = req.body;
    if (!name || !username || !email) {
      return res.status(400).json({ error: 'Name, username, and email are required' });
    }

    const newUser: User = {
      id: `USR-${Math.floor(10000 + Math.random() * 90000)}`,
      name,
      username,
      email,
      phone: phone || '',
      ffUid: ffUid || `${Math.floor(100000000 + Math.random() * 900000000)}`,
      inGameName: inGameName || username,
      avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
      role: 'user',
      walletBalance: 50, // Welcome signup bonus
      totalEarnings: 0,
      totalMatches: 0,
      totalWins: 0,
      winRate: 0,
      status: 'Active',
      createdAt: new Date().toISOString(),
    };

    db.users.push(newUser);

    // Welcome transaction
    db.transactions.unshift({
      id: `TXN-${Date.now().toString().slice(-5)}`,
      userId: newUser.id,
      userName: newUser.username,
      type: 'Admin Bonus',
      amount: 50,
      currency: 'BDT',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Approved',
      description: 'Welcome Sign-up Bonus',
    });

    saveDB(db);
    res.json({ user: newUser, token: `mock-token-${newUser.id}` });
  });

  router.get('/users', (req, res) => {
    res.json(db.users);
  });

  router.put('/users/:id', (req, res) => {
    const idx = db.users.findIndex(u => u.id === req.params.id);
    if (idx !== -1) {
      db.users[idx] = { ...db.users[idx], ...req.body };
      saveDB(db);
      res.json(db.users[idx]);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });

  // Tournaments
  router.get('/tournaments', (req, res) => {
    res.json(db.tournaments);
  });

  router.get('/tournaments/:id', (req, res) => {
    const trn = db.tournaments.find(t => t.id === req.params.id);
    if (trn) {
      res.json(trn);
    } else {
      res.status(404).json({ error: 'Tournament not found' });
    }
  });

  router.post('/tournaments', (req, res) => {
    const body = req.body;
    const newTrn: Tournament = {
      id: `TRN-${Date.now().toString().slice(-4)}`,
      title: body.title || 'New Free Fire Tournament',
      gameMode: body.gameMode || 'BR Match',
      matchType: body.matchType || 'Squad',
      map: body.map || 'Bermuda',
      bannerImage: body.bannerImage || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      description: body.description || 'Join and play to win exciting prizes.',
      rules: body.rules || '1. Play fair.\n2. No hacking allowed.\n3. Take screenshot at end.',
      entryFee: Number(body.entryFee) || 0,
      prizePool: Number(body.prizePool) || 500,
      perKillPrize: Number(body.perKillPrize) || 0,
      prizeDistribution: body.prizeDistribution || {
        rank1: Math.round((Number(body.prizePool) || 500) * 0.5),
        rank2: Math.round((Number(body.prizePool) || 500) * 0.3),
        rank3: Math.round((Number(body.prizePool) || 500) * 0.2),
        perKill: Number(body.perKillPrize) || 0,
      },
      maxSlots: Number(body.maxSlots) || 48,
      joinedSlots: 0,
      matchDate: body.matchDate || new Date().toISOString().split('T')[0],
      matchTime: body.matchTime || '08:00 PM',
      roomId: body.roomId || '',
      roomPassword: body.roomPassword || '',
      isRoomPublished: Boolean(body.isRoomPublished),
      status: body.status || 'Registration Open',
      createdAt: new Date().toISOString(),
    };

    db.tournaments.unshift(newTrn);

    // Broadcast notification
    db.notifications.unshift({
      id: `NOT-${Date.now().toString().slice(-5)}`,
      title: `New Tournament: ${newTrn.title}! 🏆`,
      message: `Registrations are open for ${newTrn.gameMode} (${newTrn.matchType}) on ${newTrn.matchDate} at ${newTrn.matchTime}. Prize: ৳${newTrn.prizePool}!`,
      target: 'all',
      timestamp: new Date().toISOString(),
      isRead: false,
      type: 'tournament',
    });

    saveDB(db);
    res.json(newTrn);
  });

  router.put('/tournaments/:id', (req, res) => {
    const idx = db.tournaments.findIndex(t => t.id === req.params.id);
    if (idx !== -1) {
      db.tournaments[idx] = { ...db.tournaments[idx], ...req.body };
      saveDB(db);
      res.json(db.tournaments[idx]);
    } else {
      res.status(404).json({ error: 'Tournament not found' });
    }
  });

  router.delete('/tournaments/:id', (req, res) => {
    db.tournaments = db.tournaments.filter(t => t.id !== req.params.id);
    db.participants = db.participants.filter(p => p.tournamentId !== req.params.id);
    saveDB(db);
    res.json({ success: true });
  });

  // Room Credentials publishing
  router.put('/tournaments/:id/room', (req, res) => {
    const { roomId, roomPassword, isRoomPublished } = req.body;
    const trn = db.tournaments.find(t => t.id === req.params.id);
    if (!trn) return res.status(404).json({ error: 'Tournament not found' });

    trn.roomId = roomId ?? trn.roomId;
    trn.roomPassword = roomPassword ?? trn.roomPassword;
    trn.isRoomPublished = isRoomPublished !== undefined ? isRoomPublished : trn.isRoomPublished;

    if (isRoomPublished) {
      // Send notification to participants
      db.notifications.unshift({
        id: `NOT-${Date.now().toString().slice(-5)}`,
        title: `Room Details Published: ${trn.title}! 🔑`,
        message: `Room ID: ${trn.roomId} | Password: ${trn.roomPassword}. Open Free Fire and join immediately!`,
        target: 'tournament',
        targetId: trn.id,
        timestamp: new Date().toISOString(),
        isRead: false,
        type: 'room',
      });
    }

    saveDB(db);
    res.json(trn);
  });

  // Join Tournament
  router.post('/tournaments/:id/join', (req, res) => {
    const trn = db.tournaments.find(t => t.id === req.params.id);
    if (!trn) return res.status(404).json({ error: 'Tournament not found' });

    const { userId, playerName, ffUid, teamName } = req.body;
    const user = db.users.find(u => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (trn.joinedSlots >= trn.maxSlots) {
      return res.status(400).json({ error: 'Tournament is full' });
    }

    const alreadyJoined = db.participants.some(p => p.tournamentId === trn.id && p.userId === user.id);
    if (alreadyJoined) {
      return res.status(400).json({ error: 'You have already joined this tournament' });
    }

    if (user.walletBalance < trn.entryFee) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    // Deduct entry fee
    if (trn.entryFee > 0) {
      user.walletBalance -= trn.entryFee;
      db.transactions.unshift({
        id: `TXN-${Date.now().toString().slice(-5)}`,
        userId: user.id,
        userName: user.username,
        type: 'Entry Fee',
        amount: -trn.entryFee,
        currency: 'BDT',
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'Approved',
        description: `Entry fee for ${trn.title}`,
      });
    }

    user.totalMatches += 1;

    const participant: Participant = {
      id: `PT-${Date.now().toString().slice(-5)}`,
      tournamentId: trn.id,
      userId: user.id,
      playerName: playerName || user.inGameName || user.name,
      ffUid: ffUid || user.ffUid,
      teamName: teamName || '',
      joinTime: new Date().toISOString(),
      paymentStatus: trn.entryFee > 0 ? 'Paid' : 'Free',
      status: 'Confirmed',
    };

    db.participants.push(participant);
    trn.joinedSlots += 1;
    if (trn.joinedSlots >= trn.maxSlots) {
      trn.status = 'Full';
    }

    // Notification for user
    db.notifications.unshift({
      id: `NOT-${Date.now().toString().slice(-5)}`,
      title: `Joined: ${trn.title}! ✅`,
      message: `You are registered for ${trn.title}. Match starts on ${trn.matchDate} at ${trn.matchTime}. Be ready!`,
      target: 'user',
      targetId: user.id,
      timestamp: new Date().toISOString(),
      isRead: false,
      type: 'tournament',
    });

    saveDB(db);
    res.json({ success: true, participant, tournament: trn, user });
  });

  // Participants
  router.get('/tournaments/:id/participants', (req, res) => {
    const list = db.participants.filter(p => p.tournamentId === req.params.id);
    res.json(list);
  });

  router.delete('/tournaments/:id/participants/:userId', (req, res) => {
    const { id, userId } = req.params;
    const trn = db.tournaments.find(t => t.id === id);
    const pIdx = db.participants.findIndex(p => p.tournamentId === id && p.userId === userId);
    
    if (pIdx !== -1) {
      db.participants.splice(pIdx, 1);
      if (trn) {
        trn.joinedSlots = Math.max(0, trn.joinedSlots - 1);
        if (trn.status === 'Full') trn.status = 'Registration Open';
        // Refund entry fee if any
        if (trn.entryFee > 0) {
          const user = db.users.find(u => u.id === userId);
          if (user) {
            user.walletBalance += trn.entryFee;
            db.transactions.unshift({
              id: `TXN-${Date.now().toString().slice(-5)}`,
              userId: user.id,
              userName: user.username,
              type: 'Admin Bonus',
              amount: trn.entryFee,
              currency: 'BDT',
              date: new Date().toISOString().split('T')[0],
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'Approved',
              description: `Refund for tournament ${trn.title}`,
            });
          }
        }
      }
      saveDB(db);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Participant not found' });
    }
  });

  // Match Results
  router.get('/results', (req, res) => {
    res.json(db.results);
  });

  router.post('/tournaments/:id/results', (req, res) => {
    const { results } = req.body; // array of results
    const trn = db.tournaments.find(t => t.id === req.params.id);
    if (!trn) return res.status(404).json({ error: 'Tournament not found' });

    trn.status = 'Completed';

    if (Array.isArray(results)) {
      // Remove previous results for this tournament
      db.results = db.results.filter(r => r.tournamentId !== trn.id);

      results.forEach((item: Partial<MatchResult>) => {
        const resultItem: MatchResult = {
          id: `RES-${Date.now().toString().slice(-5)}-${Math.floor(Math.random() * 1000)}`,
          tournamentId: trn.id,
          userId: item.userId,
          playerName: item.playerName || 'Player',
          ffUid: item.ffUid || '000000000',
          rank: Number(item.rank) || 1,
          kills: Number(item.kills) || 0,
          score: Number(item.score) || 100,
          prize: Number(item.prize) || 0,
        };
        db.results.push(resultItem);

        // Credit prize to user if linked
        if (resultItem.userId && resultItem.prize > 0) {
          const winner = db.users.find(u => u.id === resultItem.userId);
          if (winner) {
            winner.walletBalance += resultItem.prize;
            winner.totalEarnings += resultItem.prize;
            if (resultItem.rank === 1) winner.totalWins += 1;
            winner.winRate = winner.totalMatches > 0 ? Number(((winner.totalWins / winner.totalMatches) * 100).toFixed(1)) : 0;

            db.transactions.unshift({
              id: `TXN-${Date.now().toString().slice(-5)}`,
              userId: winner.id,
              userName: winner.username,
              type: 'Match Reward',
              amount: resultItem.prize,
              currency: 'BDT',
              date: new Date().toISOString().split('T')[0],
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'Approved',
              description: `Prize for ${trn.title} (Rank ${resultItem.rank}, ${resultItem.kills} Kills)`,
            });

            db.notifications.unshift({
              id: `NOT-${Date.now().toString().slice(-5)}`,
              title: `You Won ৳${resultItem.prize}! 🏆`,
              message: `Results published for ${trn.title}. You finished Rank ${resultItem.rank} with ${resultItem.kills} kills! Prize added to wallet.`,
              target: 'user',
              targetId: winner.id,
              timestamp: new Date().toISOString(),
              isRead: false,
              type: 'wallet',
            });
          }
        }
      });
    }

    saveDB(db);
    res.json({ success: true, tournament: trn, results: db.results.filter(r => r.tournamentId === trn.id) });
  });

  // Wallet & Transactions
  router.get('/wallet/transactions', (req, res) => {
    const { userId } = req.query;
    if (userId) {
      return res.json(db.transactions.filter(t => t.userId === userId));
    }
    res.json(db.transactions);
  });

  router.post('/wallet/deposit', (req, res) => {
    const { userId, amount, paymentMethod, accountNumber, transactionRef } = req.body;
    const user = db.users.find(u => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) return res.status(400).json({ error: 'Invalid amount' });

    // In tournament apps, automated or manual deposit approval:
    // We add transaction as Pending or Approved based on simulator mode
    const newTxn: Transaction = {
      id: `TXN-${Date.now().toString().slice(-5)}`,
      userId: user.id,
      userName: user.username,
      type: 'Deposit',
      amount: numAmount,
      currency: 'BDT',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Pending',
      description: `${paymentMethod} Deposit (${transactionRef || 'Ref: ' + accountNumber})`,
      paymentMethod,
      accountNumber,
    };

    db.transactions.unshift(newTxn);
    saveDB(db);
    res.json(newTxn);
  });

  router.post('/wallet/withdraw', (req, res) => {
    const { userId, amount, paymentMethod, accountNumber } = req.body;
    const user = db.users.find(u => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) return res.status(400).json({ error: 'Invalid amount' });
    if (user.walletBalance < numAmount) return res.status(400).json({ error: 'Insufficient balance' });

    // Deduct balance pending review
    user.walletBalance -= numAmount;

    const newTxn: Transaction = {
      id: `TXN-${Date.now().toString().slice(-5)}`,
      userId: user.id,
      userName: user.username,
      type: 'Withdrawal',
      amount: -numAmount,
      currency: 'BDT',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Pending',
      description: `Withdrawal request to ${paymentMethod} (${accountNumber})`,
      paymentMethod,
      accountNumber,
    };

    db.transactions.unshift(newTxn);
    saveDB(db);
    res.json({ transaction: newTxn, newBalance: user.walletBalance });
  });

  router.put('/wallet/transactions/:id/review', (req, res) => {
    const { status } = req.body; // 'Approved' | 'Rejected'
    const txn = db.transactions.find(t => t.id === req.params.id);
    if (!txn) return res.status(404).json({ error: 'Transaction not found' });

    const user = db.users.find(u => u.id === txn.userId);

    if (txn.status === 'Pending') {
      txn.status = status;
      if (user) {
        if (txn.type === 'Deposit' && status === 'Approved') {
          user.walletBalance += txn.amount;
        } else if (txn.type === 'Withdrawal' && status === 'Rejected') {
          // Refund deducted balance
          user.walletBalance += Math.abs(txn.amount);
        }
      }
    }

    saveDB(db);
    res.json(txn);
  });

  router.post('/wallet/adjust', (req, res) => {
    const { userId, amount, description, type } = req.body;
    const user = db.users.find(u => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const numAmount = Number(amount);
    user.walletBalance += numAmount;

    const newTxn: Transaction = {
      id: `TXN-${Date.now().toString().slice(-5)}`,
      userId: user.id,
      userName: user.username,
      type: type || (numAmount >= 0 ? 'Admin Bonus' : 'Entry Fee'),
      amount: numAmount,
      currency: 'BDT',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Approved',
      description: description || 'Admin manual balance adjustment',
    };

    db.transactions.unshift(newTxn);
    saveDB(db);
    res.json({ transaction: newTxn, user });
  });

  // Notifications
  router.get('/notifications', (req, res) => {
    res.json(db.notifications);
  });

  router.post('/notifications', (req, res) => {
    const { title, message, target, targetId, type } = req.body;
    const newNotif: NotificationItem = {
      id: `NOT-${Date.now().toString().slice(-5)}`,
      title: title || 'Announcement',
      message: message || '',
      target: target || 'all',
      targetId,
      timestamp: new Date().toISOString(),
      isRead: false,
      type: type || 'announcement',
    };

    db.notifications.unshift(newNotif);
    saveDB(db);
    res.json(newNotif);
  });

  router.put('/notifications/:id/read', (req, res) => {
    const notif = db.notifications.find(n => n.id === req.params.id);
    if (notif) notif.isRead = true;
    saveDB(db);
    res.json({ success: true });
  });

  // Support Tickets
  router.get('/support/tickets', (req, res) => {
    res.json(db.supportTickets);
  });

  router.post('/support/tickets', (req, res) => {
    const { userId, userName, userPhone, subject, message } = req.body;
    const newTicket: SupportTicket = {
      id: `TCK-${Date.now().toString().slice(-4)}`,
      userId: userId || 'Guest',
      userName: userName || 'Player',
      userPhone: userPhone || '',
      subject: subject || 'General Inquiry',
      message: message || '',
      status: 'Open',
      timestamp: new Date().toISOString(),
    };

    db.supportTickets.unshift(newTicket);
    saveDB(db);
    res.json(newTicket);
  });

  router.put('/support/tickets/:id', (req, res) => {
    const ticket = db.supportTickets.find(t => t.id === req.params.id);
    if (ticket) {
      ticket.status = req.body.status || 'Resolved';
      saveDB(db);
      res.json(ticket);
    } else {
      res.status(404).json({ error: 'Ticket not found' });
    }
  });

  // Mount API router
  app.use('/api', router);

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.join(__dirname, 'dist'))) {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎮 KHelo Tournament Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
